#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""体检引擎：把 Agent 上报的原始快照翻译成「检查项 + 评分 + 修复命令」。

设计原则：
1. 判定不依赖单一手段。防火墙看 ufw/firewalld/iptables/nft 四路，外加人工标注的云安全组。
2. 缺数据一律 unknown，不当成通过，也不当成失败。
3. 权重合计 100，fail 扣满、warn 扣一半、unknown 扣 15%。
"""

OK, WARN, FAIL, INFO, UNK = "ok", "warn", "fail", "info", "unknown"

GRADE = ((90, "优秀", "green"), (75, "良好", "teal"), (60, "待改善", "amber"), (0, "危险", "red"))

# 高危端口：对公网开放就算事故
DANGER_PORTS = {
    3306: "MySQL", 6379: "Redis", 27017: "MongoDB", 5432: "PostgreSQL",
    9200: "Elasticsearch", 11211: "Memcached", 2375: "Docker API（未加密）",
    2376: "Docker API", 5900: "VNC", 445: "SMB", 1433: "SQL Server",
    1521: "Oracle DB", 21: "FTP", 23: "Telnet", 3389: "远程桌面",
    8888: "常见宝塔/面板端口", 7001: "WebLogic",
}

WEAK_PROCS = ("x-ui", "xray", "v2ray", "clash", "hysteria", "sing-box", "宝塔", "bt-panel")


def _g(d, *keys, **kw):
    cur = d
    for k in keys:
        if not isinstance(cur, dict):
            return kw.get("default")
        cur = cur.get(k)
        if cur is None:
            return kw.get("default")
    return cur


def _mk(cid, title, status, value, detail, fix, group, weight, tag=""):
    try:
        weight = int(weight)
    except Exception:
        weight = 0
    return {"id": cid, "title": title, "status": status, "value": value,
            "detail": detail, "fix": fix, "group": group, "weight": weight, "tag": tag}


def check_ssh(sec, ports):
    out = []
    ssh = sec.get("ssh") or {}
    pw = ssh.get("password_auth")
    root = ssh.get("root_login")
    port = ssh.get("port") or 22
    src = ssh.get("source") or "sshd_config"

    if pw is None:
        out.append(_mk("ssh_pw", "SSH 密码登录", UNK, "读取失败",
                       "无法读取 sshd 配置（通常需要 root 权限，或 sshd -T 不可用）。",
                       "sudo sshd -T | grep -i passwordauthentication", "远程访问", 14))
    elif str(pw).lower() in ("no", "false", "0"):
        out.append(_mk("ssh_pw", "SSH 密码登录", OK, "已禁用",
                       "只允许密钥登录，暴力破解密码这条路已经堵死。",
                       "", "远程访问", 14))
    else:
        out.append(_mk("ssh_pw", "SSH 密码登录", FAIL, "允许密码登录",
                       "密码登录是全网扫描的首要目标。确认密钥能登录后关掉它。",
                       "sudo sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config\n"
                       "sudo sshd -t && sudo systemctl reload sshd", "远程访问", 14))

    if root is None:
        out.append(_mk("ssh_root", "Root 直接登录", UNK, "读取失败", "无法读取 PermitRootLogin。",
                       "sudo sshd -T | grep -i permitrootlogin", "远程访问", 6))
    else:
        v = str(root).lower()
        if v in ("no", "false"):
            out.append(_mk("ssh_root", "Root 直接登录", OK, "已禁用", "root 不能直接登录，攻击者得先拿到普通账号。",
                           "", "远程访问", 6))
        elif v in ("prohibit-password", "without-password"):
            out.append(_mk("ssh_root", "Root 直接登录", WARN, "仅允许密钥",
                           "root 仍可直连（但只能用密钥）。更稳的做法是禁用 root，用普通账号 + sudo。",
                           "sudo sed -i 's/^#\\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config\n"
                           "sudo systemctl reload sshd", "远程访问", 6))
        else:
            out.append(_mk("ssh_root", "Root 直接登录", WARN, "允许 root 密码/密钥登录",
                           "root 是暴力破解的默认用户名，暴露它能省掉攻击者一半功夫。",
                           "sudo sed -i 's/^#\\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config\n"
                           "sudo systemctl reload sshd", "远程访问", 6))

    exposed = [p for p in ports if p.get("port") == port and p.get("exposed")]
    if exposed:
        if port == 22:
            out.append(_mk("ssh_port", "SSH 端口", WARN, "22 端口对公网开放",
                           "22 是全网扫描器第一个试的端口，日志里 99% 是爆破。换成高位端口能少掉绝大部分噪音。",
                           "sudo sed -i 's/^#\\?Port .*/Port 2222/' /etc/ssh/sshd_config\n"
                           "sudo systemctl reload sshd\n# 记得先在云安全组放行 2222/tcp", "远程访问", 3))
        else:
            out.append(_mk("ssh_port", "SSH 端口", OK, "自定义端口 %s" % port,
                           "非 22 端口，扫描噪音显著减少。", "", "远程访问", 3))
    else:
        out.append(_mk("ssh_port", "SSH 端口", INFO, "未对公网监听",
                       "SSH 只在内网或隧道内可达，暴露面很小。", "", "远程访问", 3))

    keys = sec.get("keys") or {}
    n = keys.get("count")
    if n is None:
        out.append(_mk("ssh_keys", "授权密钥数量", UNK, "读取失败", "读不到 authorized_keys。",
                       "sudo wc -l /root/.ssh/authorized_keys", "远程访问", 4))
    elif n == 0:
        out.append(_mk("ssh_keys", "授权密钥数量", WARN, "没有密钥",
                       "没有公钥却关闭密码登录会把自己锁在门外；确认是否有其他登录方式。",
                       "cat ~/.ssh/authorized_keys", "远程访问", 4))
    elif n <= 3:
        out.append(_mk("ssh_keys", "授权密钥数量", OK, "%d 把密钥" % n,
                       "钥匙数量正常。%s" % (keys.get("note") or ""), "", "远程访问", 4))
    else:
        out.append(_mk("ssh_keys", "授权密钥数量", WARN, "%d 把密钥" % n,
                       "钥匙越多越难追踪是谁的。建议一只设备一把，删掉不用的。",
                       "cat ~/.ssh/authorized_keys | while read l; do ssh-keygen -lf /dev/stdin <<< \"$l\"; done",
                       "远程访问", 4))
    return out


def check_firewall(sec, ports, cloud_fw=False):
    fw = sec.get("firewall") or {}
    ufw = (fw.get("ufw") or "").lower()
    fwd = (fw.get("firewalld") or "").lower()
    ipt = fw.get("iptables_rules") or 0
    nft = fw.get("nft_rules") or 0

    active = ("active" in ufw and "inactive" not in ufw) or fwd == "running" or ipt >= 8 or nft >= 8
    detail_bits = []
    if ufw:
        detail_bits.append("ufw: %s" % (ufw or "未知"))
    if fwd:
        detail_bits.append("firewalld: %s" % fwd)
    if ipt:
        detail_bits.append("iptables 规则 %d 条" % ipt)
    if nft:
        detail_bits.append("nftables 规则 %d 条" % nft)
    detail = "；".join(detail_bits) or "未检测到任何防火墙组件"

    if active:
        return [_mk("firewall", "主机防火墙", OK, "已启用", detail,
                    "", "入侵防护", 12)]
    if cloud_fw:
        return [_mk("firewall", "主机防火墙", OK, "云安全组已加固（人工标注）", detail,
                    "系统内未启用防火墙，已通过云平台安全组收口。请定期核对安全组规则。",
                    "入侵防护", 12)]
    return [_mk("firewall", "主机防火墙", FAIL, "未启用", detail,
                "注意：甲骨文云如果乱改 UFW 容易失联，优先在控制台安全组收口，确认后再开主机防火墙。\n"
                "sudo ufw allow %s/tcp && sudo ufw --force enable && sudo ufw status verbose"
                % (next((p.get("port") for p in ports if p.get("proc") == "sshd"), 22)),
                "入侵防护", 12)]


def check_fail2ban(sec):
    f2b = sec.get("fail2ban") or {}
    active = f2b.get("active")
    jails = f2b.get("jails") or []
    inst = f2b.get("installed")
    if inst is False:
        return [_mk("fail2ban", "Fail2ban 防爆破", FAIL, "未安装",
                    "没有 fail2ban，SSH 和面板端口就靠密码本身扛暴力破解。",
                    "sudo apt install -y fail2ban && sudo systemctl enable --now fail2ban\n"
                    "sudo fail2ban-client status", "入侵防护", 12)]
    if active is False:
        return [_mk("fail2ban", "Fail2ban 防爆破", FAIL, "已安装未运行",
                    "装了但没跑，等于没装。",
                    "sudo systemctl enable --now fail2ban && sudo fail2ban-client status",
                    "入侵防护", 12)]
    if active is None:
        return [_mk("fail2ban", "Fail2ban 防爆破", UNK, "读取失败", "读不到 fail2ban 状态。",
                    "sudo systemctl status fail2ban --no-pager", "入侵防护", 12)]
    if not jails:
        return [_mk("fail2ban", "Fail2ban 防爆破", WARN, "运行中，但无 jail",
                    "服务在跑但没有启用任何 jail，实际不会封任何 IP。",
                    "sudo fail2ban-client status\n# 在 /etc/fail2ban/jail.local 里启用 [sshd]",
                    "入侵防护", 12)]
    banned = sum(int(j.get("banned") or 0) for j in jails)
    total = sum(int(j.get("total") or 0) for j in jails)
    names = "、".join("%s(%d)" % (j.get("name"), int(j.get("banned") or 0)) for j in jails)
    if banned > 0:
        return [_mk("fail2ban", "Fail2ban 防爆破", WARN, "正在封禁 %d 个 IP" % banned,
                    "jail：%s；累计封禁 %d 次。有封禁说明确实有人在打，防护正在工作。"
                    % (names, total),
                    "sudo fail2ban-client status sshd\nsudo fail2ban-client get sshd banip",
                    "入侵防护", 12)]
    return [_mk("fail2ban", "Fail2ban 防爆破", OK, "运行中 · %d 个 jail" % len(jails),
                "jail：%s；当前无封禁，累计 %d 次。" % (names, total),
                "", "入侵防护", 12)]


def check_exposure(sec, ports):
    exposed = [p for p in ports if p.get("exposed")]
    bad = []
    for p in exposed:
        try:
            pt = int(p.get("port") or 0)
        except Exception:
            continue
        if pt in DANGER_PORTS:
            bad.append((pt, DANGER_PORTS[pt], p.get("proc") or "?"))
    weak = [p for p in exposed
            if any(w in (p.get("proc") or "").lower() for w in WEAK_PROCS)]
    if bad:
        txt = "、".join("%d(%s/%s)" % (a, b, c) for a, b, c in bad)
        return [_mk("exposure", "高危端口暴露", FAIL, txt,
                    "这些端口一旦对公网开放，等于把数据库/面板直接交给扫描器。应只监听 127.0.0.1 或用隧道。",
                    "sudo ss -tulnp | grep -E ':(%s)\\b'\n# 改为 listen 127.0.0.1，或在安全组限制来源 IP"
                    % "|".join(str(b[0]) for b in bad), "入侵防护", 10)]
    if weak:
        names = "、".join("%s:%d" % (p.get("proc"), int(p.get("port") or 0)) for p in weak[:4])
        return [_mk("exposure", "高危端口暴露", WARN, "面板/代理端口对公网开放",
                    "%s。按开荒手册的约定，面板应绑 127.0.0.1，只通过隧道访问。" % names,
                    "# 面板设置里把监听地址改为 127.0.0.1，或 ufw deny <端口>", "入侵防护", 10)]
    return [_mk("exposure", "高危端口暴露", OK, "无高危端口对公网开放",
                "公网监听端口里没有数据库、面板、远程桌面这类高危服务。", "", "入侵防护", 10)]


def check_suspicious(sec):
    sus = sec.get("suspicious") or []
    if sus:
        first = sus[0]
        return [_mk("suspicious", "可疑进程", FAIL, "%d 个可疑进程" % len(sus),
                    "例如 PID %s %s（%s）。挖矿木马常见特征：从 /tmp 或 /dev/shm 启动、名字伪装成内核线程。"
                    % (first.get("pid"), first.get("name"), first.get("reason")),
                    "ps -eo pid,ppid,user,pcpu,args --sort=-pcpu | head -20\n"
                    "ls -l /proc/<PID>/exe  # 确认可执行文件位置", "入侵防护", 5)]
    return [_mk("suspicious", "可疑进程", OK, "未发现",
                "没有检测到从临时目录启动、或占用异常 CPU 的未知进程。", "", "入侵防护", 5)]


def check_updates(sec, host=None):
    """补丁与更新：待装补丁、安全补丁、系统是否已停止支持、内核是否落后、软件源多久没刷新。"""
    up = sec.get("updates") or {}
    host = host or {}
    out = []

    # ① 自动安全更新
    auto = up.get("auto")
    if auto is None:
        out.append(_mk("auto_update", "自动安全更新", UNK, "读取失败",
                       "读不到自动更新配置，无法判断补丁会不会自己装。",
                       "sudo apt install -y unattended-upgrades\nsudo dpkg-reconfigure -plow unattended-upgrades",
                       "补丁与更新", 5))
    elif auto:
        out.append(_mk("auto_update", "自动安全更新", OK, "已开启",
                       "安全更新会自动安装，%s。"
                       % ("当前有 %s 个待升级包。" % up.get("pending") if up.get("pending") else "当前没有待装补丁。"),
                       "", "补丁与更新", 5))
    else:
        out.append(_mk("auto_update", "自动安全更新", FAIL, "未开启",
                       "内核和 OpenSSL 的漏洞补丁不会自己装，暴露窗口可能长达几个月。",
                       "sudo apt install -y unattended-upgrades && sudo dpkg-reconfigure -plow unattended-upgrades",
                       "补丁与更新", 5))

    # ② 安全补丁
    secn = up.get("security")
    pend = up.get("pending")
    if pend is None:
        out.append(_mk("patch_security", "安全补丁", UNK, "读取失败",
                       "读不到待安装补丁数量（可能需要 root，或系统没有 apt/dnf）。",
                       "sudo apt update && apt list --upgradable",
                       "补丁与更新", 10))
    elif secn and secn > 0:
        out.append(_mk("patch_security", "安全补丁", FAIL, "%d 个安全补丁未装" % secn,
                       "共 %s 个包可升级，其中 %d 个来自安全源。这几个通常对应已公开的 CVE，"
                       "扫描器会照着 PoC 直接打。" % (pend, secn),
                       "sudo apt update && sudo apt upgrade -y\n"
                       "# 只想先补安全更新：sudo unattended-upgrade -d",
                       "补丁与更新", 10))
    elif pend and pend > 0:
        out.append(_mk("patch_security", "安全补丁", WARN, "%d 个包可升级（无安全更新）" % pend,
                       "待升级包里没有标为安全更新的，多数是功能更新。有空再升，不着急。",
                       "sudo apt update && sudo apt list --upgradable\nsudo apt upgrade -y",
                       "补丁与更新", 10))
    else:
        out.append(_mk("patch_security", "安全补丁", OK, "无待装补丁",
                       "系统补丁是最新的，这一项暂时不用管。",
                       "", "补丁与更新", 10))

    # ③ 系统版本是否还在支持期
    eol = os_eol(host)
    if eol is None:
        out.append(_mk("os_eol", "系统支持期", UNK, "无法判断",
                       "系统发行版不在已知清单里，需要人工确认是否还在安全支持周期内。",
                       "cat /etc/os-release", "补丁与更新", 6))
    elif eol["days"] < 0:
        out.append(_mk("os_eol", "系统支持期", FAIL, "已停止支持",
                       "%s 已于 %s 结束支持，官方不再发任何安全补丁。继续用等于把已知漏洞长期留在机器上。"
                       % (eol["name"], eol["date"]),
                       "# 建议尽快升级发行版；短期内至少把应用层收口到隧道后面\n"
                       "do-release-upgrade   # Ubuntu\n# Debian 需改 sources.list 后 dist-upgrade",
                       "补丁与更新", 6))
    elif eol["days"] < 90:
        out.append(_mk("os_eol", "系统支持期", WARN, "剩 %d 天" % eol["days"],
                       "%s 将于 %s 结束支持，之后不再有安全补丁。提前规划升级。"
                       % (eol["name"], eol["date"]),
                       "do-release-upgrade",
                       "补丁与更新", 6))
    else:
        out.append(_mk("os_eol", "系统支持期", OK, "支持到 %s" % eol["date"],
                       "%s 还在官方安全支持期内，剩 %d 天。" % (eol["name"], eol["days"]),
                       "", "补丁与更新", 6))

    # ④ 内核是否落后（装了新内核但没重启，补丁其实没生效）
    run = up.get("kernel_running") or ""
    newest = up.get("kernel_newest") or ""
    if run and newest and _vkey(newest) > _vkey(run):
        out.append(_mk("kernel_pending", "内核版本", WARN, "待重启生效",
                       "正在跑 %s，磁盘上已装 %s。新内核的补丁要重启才生效。" % (run, newest),
                       "sudo reboot", "补丁与更新", 2))
    elif run:
        out.append(_mk("kernel_pending", "内核版本", OK, run,
                       "运行内核与已安装的最新内核一致。", "", "补丁与更新", 2))

    # ⑤ 软件源多久没刷新
    age = up.get("check_age_days")
    if age is None:
        pass
    elif age > 7:
        out.append(_mk("update_check", "软件源刷新", WARN, "%d 天未刷新" % int(age),
                       "本地包索引是 %d 天前的，看到的“可升级”列表已经不准了，"
                       "可能漏掉刚发布的安全补丁。" % int(age),
                       "sudo apt update", "补丁与更新", 2))
    else:
        out.append(_mk("update_check", "软件源刷新", OK, "%.1f 天前刷新" % age,
                       "包索引较新，补丁数量可信。", "", "补丁与更新", 2))

    # ⑥ 重要软件版本
    pk = up.get("pkgs") or []
    old = [p for p in pk if p.get("upgradable")]
    if not pk:
        pass
    elif old:
        names = "、".join("%s %s→%s" % (p["label"], p["installed"], p["candidate"]) for p in old[:4])
        out.append(_mk("pkg_outdated", "重要软件更新", WARN, "%d 个可升级" % len(old),
                       "%s。这些是对外暴露的服务，补丁优先级高于一般系统包。" % names,
                       "sudo apt install --only-upgrade %s" % " ".join(p["pkg"] for p in old[:6]),
                       "补丁与更新", 4))
    else:
        out.append(_mk("pkg_outdated", "重要软件更新", OK, "%d 个组件均为最新" % len(pk),
                       "SSH、OpenSSL、Web 服务等关键组件没有可用更新。", "", "补丁与更新", 4))

    if up.get("reboot_required"):
        out.append(_mk("reboot", "待重启", WARN, "有更新需要重启",
                       "内核或关键库已升级但没重启，新补丁还没真正生效。",
                       "sudo reboot", "系统维护", 0))
    return out


def _vkey(v):
    parts = [p for p in __import__("re").split(r"[.\-]", v or "") if p]
    out = []
    for p in parts:
        try:
            out.append(int(p))
        except Exception:
            out.append(0)
    return out


# 官方安全支持截止日期（只列常见的发行版，未列的返回 None 交给人工判断）
EOL = {
    "ubuntu": {"14.04": "2019-04-30", "16.04": "2021-04-30", "18.04": "2023-05-31",
               "20.04": "2025-05-31", "22.04": "2027-04-30", "24.04": "2029-04-30",
               "24.10": "2025-07-10", "25.04": "2026-01-15", "26.04": "2031-04-30"},
    "debian": {"9": "2022-06-30", "10": "2024-06-30", "11": "2026-08-31",
               "12": "2028-06-30", "13": "2030-06-30"},
    "centos": {"7": "2024-06-30", "8": "2021-12-31", "9": "2027-05-31"},
    "rocky": {"8": "2029-05-31", "9": "2032-05-31"},
    "almalinux": {"8": "2029-03-01", "9": "2032-05-31"},
    "alpine": {},
}


def os_eol(host):
    oid = (host.get("os_id") or "").lower()
    ver = (host.get("os_ver") or "").strip()
    if not oid or not ver:
        return None
    table = EOL.get(oid)
    if not table:
        return None
    key = ver
    if oid in ("debian", "centos", "rocky", "almalinux"):
        key = ver.split(".")[0]
    date = table.get(key) or table.get(ver)
    if not date:
        return None
    try:
        from datetime import date as _d
        y, m, d = [int(x) for x in date.split("-")]
        end = _d(y, m, d)
        days = (end - _d.today()).days
    except Exception:
        return None
    name = "%s %s" % (host.get("os") or oid, ver)
    return {"name": name, "date": date, "days": days}


def check_time(sec):
    t = sec.get("time") or {}
    synced = t.get("synced")
    if synced is None:
        return [_mk("time_sync", "时间同步", UNK, "读取失败", "读不到 NTP 同步状态。",
                    "timedatectl status | grep -i 'synchronized'", "系统维护", 2)]
    if synced:
        return [_mk("time_sync", "时间同步", OK, "已同步 %s" % (t.get("service") or ""),
                    "时间准，TLS 证书校验和日志时间线才可信。", "", "系统维护", 2)]
    return [_mk("time_sync", "时间同步", WARN, "未同步",
                "时间漂移会导致证书校验失败、日志对不上时间，也让 fail2ban 判定异常。",
                "sudo timedatectl set-ntp true && timedatectl status", "系统维护", 2)]


def check_bbr(sec):
    b = sec.get("bbr") or {}
    cc = b.get("cc") or "unknown"
    qdisc = b.get("qdisc") or "-"
    enabled = b.get("enabled")
    if cc == "bbr":
        return [_mk("bbr", "BBR 加速", OK, "已开启 · %s" % qdisc,
                    "拥塞控制 bbr，队列 %s。跨境线路通常能明显提升吞吐、降低丢包敏感度。" % qdisc,
                    "", "网络优化", 3)]
    if enabled is False:
        return [_mk("bbr", "BBR 加速", FAIL, "未开启 · 当前 %s" % cc,
                    "内核未启用 fq/bbr（或模块没加载），高延迟链路上会明显吃亏。",
                    "echo -e 'net.core.default_qdisc=fq\\nnet.ipv4.tcp_congestion_control=bbr' "
                    "| sudo tee /etc/sysctl.d/99-bbr.conf\n"
                    "sudo sysctl --system && sysctl net.ipv4.tcp_congestion_control", "网络优化", 3)]
    return [_mk("bbr", "BBR 加速", WARN, "未开启 · 当前 %s" % cc,
                "正在用 %s。如果这台是跨境线路，建议换 bbr。" % cc,
                "echo -e 'net.core.default_qdisc=fq\\nnet.ipv4.tcp_congestion_control=bbr' "
                "| sudo tee /etc/sysctl.d/99-bbr.conf && sudo sysctl --system",
                "网络优化", 3)]


def build(server, payload, ctx=None):
    """返回 {score, grade, color, groups, counts, headline, keepalive}"""
    ctx = ctx or {}
    p = payload or {}
    sec = p.get("sec") or {}
    ports = p.get("ports") or []
    cloud_fw = bool(server["cloud_fw"]) if server is not None and "cloud_fw" in server.keys() else False

    items = []
    items += check_ssh(sec, ports)
    items += check_firewall(sec, ports, cloud_fw)
    items += check_fail2ban(sec)
    items += check_exposure(sec, ports)
    items += check_suspicious(sec)
    items += check_updates(sec, p.get("host") or {})
    items += check_time(sec)
    items += check_bbr(sec)

    # 权重合计不一定正好 100（以后加检查项也不用改别处），按比例归一化
    penalty = {FAIL: 1.0, WARN: 0.5, UNK: 0.15, OK: 0.0, INFO: 0.0}
    total_w = sum(i["weight"] for i in items) or 1
    lost = sum(i["weight"] * penalty.get(i["status"], 0) for i in items)
    score = max(0, min(100, int(round(100 - lost * 100.0 / total_w))))
    grade, color = GRADE[-1][1], GRADE[-1][2]
    for th, g, c in GRADE:
        if score >= th:
            grade, color = g, c
            break

    order = ["远程访问", "入侵防护", "补丁与更新", "系统维护", "网络优化"]
    groups = []
    for name in order:
        gi = [i for i in items if i["group"] == name]
        if gi:
            groups.append({"name": name, "items": gi})

    counts = {"ok": sum(1 for i in items if i["status"] == OK),
              "warn": sum(1 for i in items if i["status"] == WARN),
              "fail": sum(1 for i in items if i["status"] == FAIL),
              "unknown": sum(1 for i in items if i["status"] == UNK)}

    worst = [i for i in items if i["status"] == FAIL] or [i for i in items if i["status"] == WARN]
    headline = worst[0]["title"] + "：" + worst[0]["value"] if worst else "未发现明显风险"

    return {"score": score, "grade": grade, "color": color, "groups": groups,
            "counts": counts, "headline": headline,
            "keepalive": keepalive_info(server, p, ctx),
            "traffic": traffic_info(server, p)}


def keepalive_info(server, p, ctx):
    ka = p.get("keepalive") or {}
    detected = ka.get("detected")
    if detected is None:
        # 退化为按 cron 关键字判断
        kw = ("keepalive", "keep-alive", "保活", "oracle", "stress", "dd if=/dev/zero", "sleep 1")
        hits = [c for c in (p.get("cron") or [])
                if any(k in (c.get("cmd") or "").lower() for k in kw)]
        detected = bool(hits)
        evidence = ["%s：%s" % (c.get("src"), (c.get("cmd") or "")[:80]) for c in hits[:3]]
    else:
        evidence = ka.get("evidence") or []

    avg = ctx.get("avg_cpu_7d")
    idle_risk = None
    if avg is not None and ctx.get("hours", 0) >= 24:
        idle_risk = avg < 2.0 and not detected
    return {"detected": bool(detected), "evidence": evidence,
            "avg_cpu_7d": avg, "idle_risk": idle_risk,
            "note": ka.get("note") or ""}


def traffic_info(server, p):
    net = p.get("net") or {}
    quota_gb = server["quota_gb"] if server is not None and "quota_gb" in server.keys() else 0
    mr = net.get("month_rx") or 0
    mt = net.get("month_tx") or 0
    total = mr + mt
    pct = None
    if quota_gb:
        pct = round(total / (quota_gb * 1024.0 ** 3) * 100, 1)
    return {"rx": mr, "tx": mt, "total": total, "quota_gb": quota_gb, "pct": pct}


def port_risks(ports):
    out = []
    for p in ports or []:
        try:
            pt = int(p.get("port") or 0)
        except Exception:
            continue
        note, level = "", ""
        if pt in DANGER_PORTS:
            note, level = DANGER_PORTS[pt] + " 对公网开放", "fail"
        elif any(w in (p.get("proc") or "").lower() for w in WEAK_PROCS) and p.get("exposed"):
            note, level = "面板/代理端口，建议绑 127.0.0.1", "warn"
        elif pt == 22 and p.get("exposed"):
            note, level = "SSH 默认端口，爆破噪音大", "warn"
        if note:
            out.append({"port": pt, "level": level, "note": note})
    return out
