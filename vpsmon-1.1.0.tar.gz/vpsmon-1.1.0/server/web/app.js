/* VPS 监控平台 · 前端（无框架、无构建） */
const app = document.getElementById('app');
const topRight = document.getElementById('topRight');
const navEl = document.getElementById('nav');
const toastEl = document.getElementById('toast');

const S = {
  showSec: localStorage.getItem('vpsmon_showsec') === '1', view: '', id: '', tab: 'overview', data: null, ov: null, alerts: null,
            settings: null, alertFilter: 'open', newServer: null, timer: null };

const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s === undefined || s === null ? '' : s)
  .replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function fmtB(n) {
  n = Number(n || 0);
  if (n < 1024) return n + ' B';
  const u = ['KB', 'MB', 'GB', 'TB', 'PB'];
  let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return (n >= 100 ? n.toFixed(0) : n >= 10 ? n.toFixed(1) : n.toFixed(2)) + ' ' + u[i];
}
function fmtBs(n) {
  n = Number(n || 0);
  if (n < 1024) return n + ' B';
  const u = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return (n >= 100 || i <= 1 ? n.toFixed(0) : n.toFixed(1)) + ' ' + u[i];
}
function fmtRate(n) { return fmtB(n) + '/s'; }
// Y 轴刻度用：字节数取整到 KB/MB，避免 "0.97 MB" 这类读数
function tickRate(v) {
  v = Number(v || 0);
  if (v >= 1000 * 1024 ** 2) return (v / 1024 ** 3).toFixed(1) + ' GB';
  if (v >= 1000 * 1024) return (v / 1024 ** 2).toFixed(1) + ' MB';
  if (v >= 1024) return Math.round(v / 1024) + ' KB';
  return Math.round(v) + ' B';
}
function pct(n) { return (Math.round(Number(n || 0) * 10) / 10) + '%'; }
function ago(ts) {
  if (!ts) return '从未';
  const d = Math.max(0, Date.now() / 1000 - ts);
  if (d < 60) return Math.round(d) + ' 秒前';
  if (d < 3600) return Math.round(d / 60) + ' 分钟前';
  if (d < 86400) return Math.round(d / 3600) + ' 小时前';
  return Math.round(d / 86400) + ' 天前';
}
function dur(sec) {
  sec = Number(sec || 0);
  const d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  return d ? `${d} 天 ${h} 小时` : h ? `${h} 小时 ${m} 分` : `${m} 分钟`;
}
function toast(msg) {
  toastEl.textContent = msg;
  toastEl.style.opacity = 1;
  toastEl.style.transform = 'translateX(-50%) translateY(0)';
  clearTimeout(toast._t);
  toast._t = setTimeout(() => {
    toastEl.style.opacity = 0;
    toastEl.style.transform = 'translateX(-50%) translateY(20px)';
  }, 2200);
}
async function api(path, body) {
  const opt = body === undefined ? {} : {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  };
  const r = await fetch(path, opt);
  if (r.status === 401) { location.href = '/login'; throw new Error('未登录'); }
  let d = {};
  try { d = await r.json(); } catch (e) { }
  if (!r.ok) throw new Error(d.error || ('请求失败 ' + r.status));
  return d;
}
async function copy(text) {
  try { await navigator.clipboard.writeText(text); toast('已复制'); }
  catch (e) {
    const t = document.createElement('textarea');
    t.value = text; document.body.appendChild(t); t.select();
    document.execCommand('copy'); t.remove(); toast('已复制');
  }
}

/* ---------------- 图表 ---------------- */
function spark(vals, color) {
  if (!vals || vals.length < 2) return '';
  const W = 100, H = 30, max = Math.max(...vals, 1), min = Math.min(...vals, 0);
  const pts = vals.map((v, i) => [
    (i / (vals.length - 1)) * W,
    H - 2 - ((v - min) / (max - min || 1)) * (H - 6)
  ]);
  const line = pts.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
  const area = `0,${H} ` + line + ` ${W},${H}`;
  return `<svg class="spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="width:100%;height:30px;display:block">
    <polygon points="${area}" fill="${color}" opacity=".09"/>
    <polyline points="${line}" fill="none" stroke="${color}" stroke-width="1.6" stroke-linejoin="round"/>
  </svg>`;
}

// 把刻度步长取成 1 / 2 / 2.5 / 5 的整数倍，避免出现 293KB 这种读数
function niceStep(raw) {
  if (!(raw > 0)) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(raw)));
  const f = raw / p;
  const m = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10;
  return m * p;
}

function lineChart(series, keys, opts) {
  opts = opts || {};
  // PL 留够宽，长标签（如 "1.5 MB"）不再被裁掉
  const W = 640, H = opts.h || 130, PL = 46, PR = 8, PT = 12, PB = 20;
  const n = series.length;
  if (!n) return '<div class="empty" style="padding:26px">暂无数据</div>';
  let max = opts.max || 0;
  if (!max) keys.forEach((k) => series.forEach((d) => { max = Math.max(max, Number(d[k]) || 0); }));
  max = max || 1;
  let step = max / 3;
  if (!opts.max) {
    // 字节轴按 1024 取整，刻度才会是 500 KB / 1.0 MB 而不是 488 KB
    step = opts.byte ? niceStep(max / 1024 / 3) * 1024 : niceStep(max / 3);
    max = step * 3;
  }
  const X = (i) => PL + (W - PL - PR) * (i / Math.max(1, n - 1));
  const Y = (v) => PT + (H - PT - PB) * (1 - (Number(v) || 0) / max);
  let g = '';
  for (let i = 0; i <= 3; i++) {
    const v = step * i, y = Y(v);
    g += `<line x1="${PL}" y1="${y.toFixed(1)}" x2="${W - PR}" y2="${y.toFixed(1)}" stroke="#eef0f5" stroke-width="1"/>
          <text x="${PL - 6}" y="${(y + 3).toFixed(1)}" text-anchor="end" font-size="9" fill="#9aa3b2">${opts.fmt ? opts.fmt(v) : Math.round(v)}</text>`;
  }
  let paths = '';
  keys.forEach((k, ki) => {
    const col = (opts.colors || [])[ki] || '#1f6feb';
    const pts = series.map((d, i) => `${X(i).toFixed(1)},${Y(d[k]).toFixed(1)}`).join(' ');
    if (opts.area && keys.length === 1) {
      paths += `<polygon points="${PL},${H - PB} ${pts} ${W - PR},${H - PB}" fill="${col}" opacity=".07"/>`;
    }
    paths += `<polyline points="${pts}" fill="none" stroke="${col}" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>`;
  });
  const t0 = series[0].ts || series[0].hour * 1000 || 0;
  const t1 = series[n - 1].ts || series[n - 1].hour * 1000 || 0;
  const fmtT = (t) => {
    if (!t) return '';
    const d = new Date(t);
    return opts.hour ? `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:00`
      : `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };
  return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="width:100%;height:${H}px;display:block">
    ${g}${paths}
    <text x="${PL}" y="${H - 5}" font-size="9" fill="#9aa3b2">${fmtT(t0)}</text>
    <text x="${W - PR}" y="${H - 5}" text-anchor="end" font-size="9" fill="#9aa3b2">${fmtT(t1)}</text>
  </svg>`;
}

function ring(p, label, color) {
  const v = Math.max(0, Math.min(100, Number(p) || 0));
  const c = v >= 90 ? 'var(--bad)' : v >= 75 ? 'var(--warn)' : color;
  return `<div class="ring"><div class="dial" style="--p:${v};--c:${c}">
    <div class="val">${Math.round(v)}<i>%</i></div></div><div class="lb">${label}</div></div>`;
}
function bigRing(score, color) {
  const map = { green: '#16a34a', teal: '#0d9488', amber: '#d97706', red: '#dc2626' };
  return `<div class="big-ring" style="--p:${score};--c:${map[color] || '#1f6feb'}">
    <div class="in"><b>${score}</b><small>安全评分</small></div></div>`;
}
const SCORE_CLS = { green: 's-green', teal: 's-teal', amber: 's-amber', red: 's-red' };
const LEVEL_TXT = { ok: '通过', warn: '警告', fail: '失败', unknown: '未知', info: '提示' };
const MARK = { ok: '✓', warn: '!', fail: '×', unknown: '?', info: 'i' };

/* ---------------- 顶栏 ---------------- */
function renderTop() {
  const v = S.ov ? S.ov.summary : null;
  topRight.innerHTML = (v ? `
    <span class="pill ${v.offline ? 'bad' : 'ok'}">在线 <b>${v.online}</b>/${v.total}</span>
    <span class="pill ${v.alerts ? 'bad' : ''}">告警 <b>${v.alerts}</b></span>
    ${S.showSec ? `<span class="pill">均分 <b>${v.avg_score}</b></span>` : ''}` : '') +
    `<button class="ghost" data-act="logout">退出</button>`;
  [...navEl.children].forEach((a) => {
    const on = (a.dataset.v === 'overview' && S.view === 'overview') ||
      (a.dataset.v === 'alerts' && S.view === 'alerts') ||
      (a.dataset.v === 'settings' && S.view === 'settings') ||
      (a.dataset.v === 'overview' && S.view === 'detail');
    a.classList.toggle('on', on);
  });
}

/* ---------------- 总览 ---------------- */
function cardHTML(c) {
  if (c.empty) {
    return `<div class="card srv" data-act="open" data-id="${c.id}">
      <div class="hd"><i class="st off"></i><div class="nm">${esc(c.name)}</div></div>
      <div class="meta">等待 Agent 上报…</div>
      <div class="hint">刚添加的机器通常 10 秒内出现数据。若一直为空，检查 Agent 服务状态。</div>
      <div class="headline">安装命令在「设置」里可以再次复制</div>
    </div>`;
  }
  const f = c.flags || {};
  const chip = (txt, st) => `<span class="chip ${st || ''}">${txt}</span>`;
  const host = c.host || {};
  const meta = [
    (host.os || '').replace(' GNU/Linux', ''),
    host.cores ? host.cores + ' 核' : '',
    c.mem.total ? fmtB(c.mem.total).replace('.00 ', ' ') : '',
    c.disk.total ? fmtB(c.disk.total).replace('.00 ', ' ') : '',
    host.ip || ''
  ].filter(Boolean).join(' · ');
  return `<div class="card srv" data-act="open" data-id="${c.id}">
    <div class="hd"><i class="st ${c.online ? '' : 'off'}"></i><div class="nm">${esc(c.name)}</div>
      ${c.grp ? `<span class="grp-tag">${esc(c.grp)}</span>` : ''}
      ${S.showSec ? `<span class="score ${SCORE_CLS[c.color] || 's-teal'}" title="${esc(c.grade)}">${c.score}</span>` : ''}</div>
    <div class="meta">${esc(meta)}</div>
    <div class="rings">
      ${ring(c.cpu.pct, 'CPU', '#1f6feb')}
      ${ring(c.mem.pct, '内存', '#7c3aed')}
      ${ring(c.disk.pct, '磁盘', '#0d9488')}
    </div>
    <div class="nums"><span>负载 ${c.cpu.load1 ?? '-'}</span>
      <span>${fmtBs(c.mem.used)} / ${fmtBs(c.mem.total)}</span>
      <span>${fmtBs(c.disk.used)} / ${fmtBs(c.disk.total)}</span></div>
    <div class="netline"><span>↓ ${fmtRate(c.net.rx)}</span><span>↑ ${fmtRate(c.net.tx)}</span></div>
    ${spark(c.spark, '#1f6feb')}
    ${S.showSec ? `<div class="chips">
      ${chip(f.firewall === 'ok' ? '防火墙' : f.firewall === 'fail' ? '无防火墙' : '防火墙?', f.firewall === 'ok' ? 'ok' : 'bad')}
      ${chip(f.fail2ban === 'ok' ? 'Fail2ban' : f.fail2ban === 'fail' ? '无 Fail2ban' : 'Fail2ban?', f.fail2ban === 'ok' ? 'ok' : 'bad')}
      ${chip(f.bbr === 'ok' ? 'BBR' : 'BBR 未开', f.bbr === 'ok' ? 'ok' : 'warn')}
      ${chip(f.ssh_pw === 'ok' ? '仅密钥' : '密码登录', f.ssh_pw === 'ok' ? 'ok' : 'bad')}
      ${chip(c.keepalive ? '保活中' : '无保活', c.keepalive ? 'ok' : '')}
    </div>
    <div class="headline">${esc(c.headline || '')}</div>
    <div class="sechide" data-act="hidesec">收起安全信息</div>`
      : `<div class="secmask" data-act="showsec"><span>安全信息已隐藏</span><b>点击显示</b></div>`}
  </div>`;
}

function renderOverview() {
  const d = S.ov;
  if (!d) { app.innerHTML = '<div class="empty">加载中…</div>'; return; }
  if (!d.servers.length) {
    app.innerHTML = `<div class="card empty"><b>还没有服务器</b>
      去「设置」添加第一台，复制一行安装命令到 VPS 上执行即可。</div>`;
    return;
  }
  app.innerHTML = `<div class="toolbar" style="margin-bottom:12px">
      <span class="hint">共 ${d.servers.length} 台 · 点击卡片查看详情 · 每 5 秒自动刷新</span>
      <div class="grow"></div>
      <span class="hint">${new Date().toLocaleTimeString('zh-CN', { hour12: false })} 更新</span>
      <button class="ghost" data-act="togglesec" style="margin-left:10px">
        ${S.showSec ? '隐藏安全信息' : '显示安全信息'}</button>
    </div>
    <div class="grid">${d.servers.map(cardHTML).join('')}</div>`;
}

/* ---------------- 详情 ---------------- */
function tabsHTML() {
  const t = [['overview', '概览'], ['sec', '安全体检'], ['upd', '更新与补丁'],
  ['ports', '端口与服务'], ['cron', '定时与保活'], ['hist', '历史与变更']];
  return `<div class="tabs">${t.map(([k, n]) =>
    `<button data-act="tab" data-tab="${k}" class="${S.tab === k ? 'on' : ''}">${n}</button>`).join('')}</div>`;
}

function kvGrid(pairs) {
  return `<div class="kv">${pairs.map(([k, v]) =>
    `<div><b>${esc(k)}</b><span>${v}</span></div>`).join('')}</div>`;
}

// 只保留窗口内的点，避免数据断档时把几小时前的点画成"近 30 分钟"
function recent(arr, sec) {
  const cut = Date.now() / 1000 - sec;
  return (arr || []).filter((x) => (x.ts || 0) >= cut);
}

function tabOverview(d) {
  const p = d.payload, host = d.host || {}, cpu = p.cpu || {}, mem = p.mem || {}, net = p.net || {};
  const swap = p.swap || {};
  const top = (cpu.top || []).slice(0, 6);
  return `
  <div class="row" style="align-items:stretch">
    <div class="card panel" style="flex:1 1 420px">
      <div class="rings" style="gap:14px">
        ${['CPU', '内存', '磁盘'].map((lb, i) => {
    const v = i === 0 ? cpu.pct : i === 1 ? mem.pct : (p.disks || [{}])[0].pct;
    return `<div style="flex:1">${ring(v, lb + ' 使用率', ['#1f6feb', '#7c3aed', '#0d9488'][i])}</div>`;
  }).join('')}
      </div>
      <div class="sep"></div>
      ${kvGrid([
    ['负载 1 / 5 / 15', `${cpu.load1 ?? '-'} / ${cpu.load5 ?? '-'} / ${cpu.load15 ?? '-'}`],
    ['内存', `${fmtBs(mem.used)} / ${fmtBs(mem.total)}`],
    ['缓存 / Buffer', fmtBs(mem.cached)],
    ['Swap', swap.total ? `${fmtB(swap.used)} / ${fmtB(swap.total)}` : '未启用'],
    ['TCP 连接', `${net.conns ?? '-'} 个 · 已建立 ${net.estab ?? '-'}`],
    ['实时带宽', `↓ ${fmtRate(net.rx_bps)} · ↑ ${fmtRate(net.tx_bps)}`],
    ['本月流量', `${fmtB((net.month_rx || 0) + (net.month_tx || 0))}${d.checks.traffic.pct !== null ? ' · 配额 ' + d.checks.traffic.pct + '%' : ''}`],
  ])}
    </div>
    <div class="card panel" style="flex:1 1 320px">
      <div class="sec-title" style="margin:0 0 10px"><h2>系统</h2></div>
      ${kvGrid([
    ['主机名', esc(host.hostname || '-')],
    ['系统', esc(host.os || '-')],
    ['内核', esc(host.kernel || '-')],
    ['架构', esc(host.arch || '-')],
    ['虚拟化', esc(host.virt || '物理机/未知')],
    ['CPU', `${esc(host.cpu_model || '-')}`],
    ['核心', `${host.cores || '-'} 核 / ${host.threads || '-'} 线程`],
    ['运行时长', dur(host.uptime)],
    ['厂商', esc(host.vendor || '-')],
    ['Agent', esc(d.agent_ver || '-')],
    ['公网 IP', esc(host.ip || '-')],
    ['开机时间', host.boot_ts ? new Date(host.boot_ts * 1000).toLocaleDateString('zh-CN') : '-'],
  ])}
    </div>
  </div>
  ${recent(d.series, 1800).length > 2 ? `<div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 6px"><h2>近 30 分钟</h2><span>10 秒粒度 · CPU / 内存 / 磁盘</span></div>
    ${lineChart(recent(d.series, 1800).map((x) => ({ ts: x.ts * 1000, cpu: x.cpu, mem: x.mem, disk: x.disk })),
    ['cpu', 'mem', 'disk'], { max: 100, colors: ['#1f6feb', '#7c3aed', '#0d9488'], fmt: (v) => Math.round(v) + '%' })}
  </div>` : ''}
  <div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 10px"><h2>资源占用 Top</h2><span>按 CPU 排序</span></div>
    <table><thead><tr><th>PID</th><th>进程</th><th>CPU</th><th>内存</th><th>命令</th></tr></thead><tbody>
    ${top.map((t) => `<tr><td class="mono muted">${esc(t.pid)}</td><td>${esc(t.name)}</td>
      <td>${t.cpu}%</td><td>${t.mem}% · ${fmtB(t.rss)}</td>
      <td class="mono muted" style="max-width:420px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(t.cmd)}</td></tr>`).join('') ||
    '<tr><td colspan="5" class="muted">无数据</td></tr>'}
    </tbody></table>
  </div>`;
}

function tabSec(d) {
  const ck = d.checks;
  return `
  <div class="card panel">
    <div class="scorbox">
      ${bigRing(ck.score, ck.color)}
      <div style="flex:1;min-width:220px">
        <div style="font-size:16px;font-weight:600;margin-bottom:3px">${esc(ck.grade)}</div>
        <div class="muted" style="font-size:13px">${esc(ck.headline)}</div>
        <div class="chips" style="margin-top:10px">
          <span class="tag green">通过 ${ck.counts.ok}</span>
          <span class="tag amber">警告 ${ck.counts.warn}</span>
          <span class="tag red">失败 ${ck.counts.fail}</span>
          ${ck.counts.unknown ? `<span class="tag">未知 ${ck.counts.unknown}</span>` : ''}
        </div>
      </div>
      <div class="prio">
        <div class="prio-hd">${ck.counts.fail ? '优先处理' : '检查结论'}</div>
        ${ck.groups.flatMap((g) => g.items).filter((i) => i.status === 'fail').slice(0, 3)
      .map((i) => `<div class="pi"><i></i><div><b>${esc(i.title)}</b> · ${esc(i.value)}</div></div>`).join('')
      || (ck.counts.warn
        ? `<div class="pi" style="color:var(--warn)"><i style="background:var(--warn)"></i><div>没有失败项，${ck.counts.warn} 项可继续优化</div></div>`
        : '<div class="pi" style="color:var(--ok)"><i style="background:var(--ok)"></i><div>全部通过，保持现状即可</div></div>')}
        ${d.cloud_fw ? '<div class="pi"><i style="background:var(--ok)"></i><div>已标注云安全组收口</div></div>' : ''}
      </div>
    </div>
  </div>
  ${ck.groups.map((g) => `
    <div class="sec-title"><h2>${esc(g.name)}</h2><span>${g.items.filter((i) => i.status === 'fail').length} 项失败${g.items.filter((i) => i.status === 'warn').length ? ' · ' + g.items.filter((i) => i.status === 'warn').length + ' 项警告' : ''}</span></div>
    <div class="items">${g.items.map(itemHTML).join('')}</div>`).join('')}`;
}

function itemHTML(i) {
  return `<div class="item ${i.status}">
    <div class="ih"><i class="dot-s ${i.status}">${MARK[i.status] || ''}</i>
      <span class="t">${esc(i.title)}</span><span class="v">${esc(i.value)}</span></div>
    <div class="d">${esc(i.detail)}</div>
    ${i.fix ? `<details class="fix-d"><summary>查看修复命令</summary>
      <div class="fixbox"><pre>${esc(i.fix)}</pre>
      <button class="copy" data-act="copy" data-text="${esc(i.fix)}">复制</button></div></details>` : ''}
  </div>`;
}

function tabUpd(d) {
  const up = ((d.payload || {}).sec || {}).updates || {};
  const pk = up.pkgs || [];
  const old = pk.filter((x) => x.upgradable);
  const secn = up.security, pend = up.pending;
  const eol = (d.checks.groups || []).flatMap((g) => g.items).find((i) => i.id === 'os_eol') || {};
  const kl = (d.checks.groups || []).flatMap((g) => g.items).find((i) => i.id === 'kernel_pending') || {};
  const tone = (n) => n > 0 ? 'bad' : 'ok';
  const apt = up.mgr === 'apt';
  const cmd = apt
    ? 'sudo apt update && sudo apt upgrade -y\n# 只装安全补丁：sudo unattended-upgrade -d'
    : 'sudo dnf upgrade --refresh -y\n# 只装安全补丁：sudo dnf upgrade --security -y';
  return `
  <div class="card panel">
    <div class="statrow">
      <div class="stat ${secn ? 'bad' : 'ok'}"><b>${secn === null || secn === undefined ? '?' : secn}</b><span>安全补丁</span></div>
      <div class="stat ${pend ? 'warn' : 'ok'}"><b>${pend === null || pend === undefined ? '?' : pend}</b><span>可升级包</span></div>
      <div class="stat"><b>${old.length}</b><span>重要软件待更新</span></div>
      <div class="stat"><b>${up.check_age_days === null || up.check_age_days === undefined ? '?' : up.check_age_days.toFixed(1)}</b><span>天前刷新索引</span></div>
    </div>
    <div class="sep"></div>
    <div class="kv">
      <div><b>系统支持期</b><span>${esc(eol.value || '-')}${eol.status === 'fail' ? ' ⚠ 已停止支持' : ''}</span></div>
      <div><b>运行内核</b><span class="mono">${esc(up.kernel_running || '-')}</span></div>
      <div><b>已装最新内核</b><span class="mono">${esc(up.kernel_newest || '-')}</span></div>
      <div><b>自动安全更新</b><span>${up.auto === null || up.auto === undefined ? '读取失败' : (up.auto ? '已开启' : '未开启')}</span></div>
      <div><b>待重启</b><span>${up.reboot_required ? '是（补丁未生效）' : '否'}</span></div>
      <div><b>包管理器</b><span>${esc(up.mgr || '未知')}</span></div>
    </div>
    ${kl.status === 'warn' ? `<div class="hint" style="margin-top:10px;color:var(--warn)">${esc(kl.detail || '')}</div>` : ''}
    <details class="fix-d" open style="margin-top:10px"><summary>更新命令</summary>
      <div class="fixbox"><pre>${esc(cmd)}</pre>
      <button class="copy" data-act="copy" data-text="${esc(cmd)}">复制</button></div></details>
  </div>

  <div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 10px"><h2>重要软件</h2>
      <span>${old.length ? old.length + ' 个有可用更新' : '均为最新'}</span></div>
    <table><thead><tr><th>组件</th><th>已装版本</th><th>仓库最新</th><th>状态</th></tr></thead><tbody>
    ${pk.map((x) => `<tr><td>${esc(x.label)}</td>
      <td class="mono muted">${esc(x.installed)}</td>
      <td class="mono muted">${esc(x.candidate || '—')}</td>
      <td>${x.upgradable ? '<span class="tag amber">可更新</span>' : '<span class="tag green">最新</span>'}</td></tr>`).join('')
      || '<tr><td colspan="4" class="muted">没有读到包信息（系统可能不是 apt/dnf，或 Agent 权限不足）</td></tr>'}
    </tbody></table>
  </div>

  <div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 10px"><h2>这项为什么会看</h2></div>
    <div class="hint" style="line-height:1.9">
      · <b>安全补丁</b>：来自发行版安全源（如 <span class="mono">jammy-security</span>）的更新，通常对应已公开的 CVE。扫描器会照着公开的 PoC 打，没装就是敞着的。<br>
      · <b>内核待重启</b>：新内核装进 /boot 但没重启时，运行的还是旧内核，补丁实际没生效。<br>
      · <b>系统支持期</b>：发行版 EOL 之后官方不再发补丁，即使显示"没有待更新"也不代表安全。<br>
      · <b>软件源刷新</b>：本地索引过期时，"可升级"列表本身就不准，可能漏掉刚发的补丁。
    </div>
  </div>`;
}

function tabPorts(d) {
  const ports = d.ports || [];
  const svc = d.services || [];
  const dk = d.docker || [];
  const certs = d.certs || [];
  return `
  <div class="card panel">
    <div class="sec-title" style="margin:0 0 10px"><h2>监听端口</h2><span>${ports.length} 个 · 红底表示对公网开放的高危服务</span></div>
    <table><thead><tr><th>端口</th><th>协议</th><th>监听地址</th><th>进程</th><th>判定</th></tr></thead><tbody>
    ${ports.map((p) => `<tr>
      <td class="mono"><b>${p.port}</b></td><td class="muted">${esc(p.proto)}</td>
      <td class="mono muted">${esc(p.addr)}</td>
      <td>${esc(p.proc || '未知')}</td>
      <td>${p.exposed ? (p.risk ? `<span class="tag ${p.risk.level === 'fail' ? 'red' : 'amber'}">${esc(p.risk.note)}</span>` : '<span class="tag amber">公网可达</span>') : '<span class="tag">仅本机</span>'}</td>
    </tr>`).join('') || '<tr><td colspan="5" class="muted">无数据</td></tr>'}
    </tbody></table>
  </div>
  <div class="row" style="margin-top:14px;align-items:flex-start">
    <div class="card panel" style="flex:1 1 320px">
      <div class="sec-title" style="margin:0 0 10px"><h2>系统服务</h2></div>
      <table><thead><tr><th>服务</th><th>状态</th><th>开机自启</th></tr></thead><tbody>
      ${svc.map((s) => `<tr><td class="mono">${esc(s.name)}</td>
        <td>${s.active ? '<span class="tag green">运行中</span>' : '<span class="tag">已停止</span>'}</td>
        <td class="muted">${s.enabled ? '是' : '否'}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">未检测到</td></tr>'}
      </tbody></table>
    </div>
    <div class="card panel" style="flex:1 1 320px">
      <div class="sec-title" style="margin:0 0 10px"><h2>容器</h2><span>${dk.length} 个</span></div>
      <table><thead><tr><th>名称</th><th>状态</th><th>镜像</th></tr></thead><tbody>
      ${dk.map((c) => `<tr><td>${esc(c.name)}</td>
        <td>${c.state === 'running' ? '<span class="tag green">运行中</span>' : `<span class="tag">${esc(c.state)}</span>`}</td>
        <td class="mono muted" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(c.image)}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">未安装 Docker 或无容器</td></tr>'}
      </tbody></table>
    </div>
  </div>
  ${certs.length ? `<div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 10px"><h2>证书</h2></div>
    <table><thead><tr><th>域名</th><th>剩余</th><th>签发者</th></tr></thead><tbody>
    ${certs.map((c) => `<tr><td>${esc(c.domain)}</td>
      <td><span class="tag ${c.days <= 7 ? 'red' : c.days <= 21 ? 'amber' : 'green'}">${c.days} 天</span></td>
      <td class="mono muted" style="max-width:420px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(c.issuer)}</td></tr>`).join('')}
    </tbody></table></div>` : ''}`;
}

function tabCron(d) {
  const ka = d.checks.keepalive || {};
  const cron = d.cron || [], timers = d.timers || [];
  return `
  <div class="card panel">
    <div class="sec-title" style="margin:0 0 8px"><h2>保活状态</h2><span>免费实例（尤其甲骨文）长期空闲可能被回收</span></div>
    <div class="row">
      <div style="flex:1 1 240px">
        <div style="font-size:15px;font-weight:600;color:${ka.detected ? 'var(--ok)' : 'var(--warn)'}">
          ${ka.detected ? '检测到保活手段' : '未检测到保活脚本'}</div>
        <div class="hint" style="margin-top:6px">
          ${ka.avg_cpu_7d !== null && ka.avg_cpu_7d !== undefined ? '近 7 天平均 CPU ' + ka.avg_cpu_7d.toFixed(1) + '%。' : '历史数据不足 7 天，暂不评估回收风险。'}
          ${ka.idle_risk ? '<br><span style="color:var(--warn)">CPU 长期低于 2% 且无保活，有一定回收风险。</span>' : ''}
        </div>
      </div>
      <div style="flex:2 1 340px">
        ${ka.evidence && ka.evidence.length ? `<div class="items">${ka.evidence.map((e) =>
    `<div class="item" style="padding:9px 12px"><span class="mono" style="font-size:12px">${esc(e)}</span></div>`).join('')}</div>`
      : '<div class="hint">常见的保活方式：cron 定时跑轻量任务、systemd timer、或用 stress 压一定 CPU。你的开荒手册里也提到过这一点。</div>'}
      </div>
    </div>
  </div>
  <div class="row" style="margin-top:14px;align-items:flex-start">
  <div class="card panel" style="flex:1 1 460px">
    <div class="sec-title" style="margin:0 0 10px"><h2>定时任务</h2><span>${cron.length} 条</span></div>
    <table><thead><tr><th>来源</th><th>计划</th><th>命令</th></tr></thead><tbody>
    ${cron.map((c) => `<tr><td class="muted">${esc(c.src)}</td><td class="mono">${esc(c.schedule)}</td>
      <td class="mono" style="max-width:520px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(c.cmd)}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">没有定时任务</td></tr>'}
    </tbody></table>
  </div>
  <div class="card panel" style="flex:1 1 360px">
    <div class="sec-title" style="margin:0 0 10px"><h2>systemd timers</h2><span>${timers.length} 个</span></div>
    <table><thead><tr><th>名称</th><th>下次触发</th><th>触发目标</th></tr></thead><tbody>
    ${timers.map((t) => `<tr><td class="mono">${esc(t.name)}</td><td class="muted">${esc(t.next)}</td><td class="muted">${esc(t.active)}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">无</td></tr>'}
    </tbody></table>
  </div>
  </div>`;
}

function tabHist(d) {
  const s = d.series || [], h = d.hourly || [];
  const ev = d.events || [];
  return `
  <div class="card panel">
    <div class="sec-title" style="margin:0 0 6px"><h2>近 30 分钟</h2><span>10 秒粒度</span></div>
    ${lineChart(recent(s, 1800).map((x) => ({ ts: x.ts * 1000, cpu: x.cpu, mem: x.mem, disk: x.disk })),
    ['cpu', 'mem', 'disk'], { max: 100, colors: ['#1f6feb', '#7c3aed', '#0d9488'], fmt: (v) => Math.round(v) + '%' })}
    <div class="chips" style="margin-top:6px">
      <span class="tag" style="background:#eaf1fe;color:#1f6feb">CPU</span>
      <span class="tag" style="background:#f3edff;color:#7c3aed">内存</span>
      <span class="tag" style="background:#e6f6f4;color:#0d9488">磁盘</span>
    </div>
  </div>
  <div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 6px"><h2>近 72 小时</h2><span>每小时均值 · CPU / 内存</span></div>
    ${lineChart(h.map((x) => ({ hour: x.hour, ts: x.hour * 1000, cpu: x.cpu, mem: x.mem })),
    ['cpu', 'mem'], { max: 100, hour: true, colors: ['#1f6feb', '#7c3aed'], fmt: (v) => Math.round(v) + '%' })}
  </div>
  <div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 6px"><h2>网络速率</h2><span>下行 / 上行</span></div>
    ${lineChart(recent(s, 1800).map((x) => ({ ts: x.ts * 1000, rx: x.rx, tx: x.tx })),
    ['rx', 'tx'], { area: true, byte: true, colors: ['#0d9488', '#d97706'], fmt: tickRate })}
  </div>
  <div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 10px"><h2>变更记录</h2><span>端口、密钥、定时任务的变化会自动留痕</span></div>
    <table><thead><tr><th>时间</th><th>类型</th><th>内容</th></tr></thead><tbody>
    ${ev.map((e) => `<tr><td class="muted" style="white-space:nowrap">${new Date(e.ts * 1000).toLocaleString('zh-CN', { hour12: false })}</td>
      <td><span class="tag ${e.level === 'critical' ? 'red' : e.level === 'warning' ? 'amber' : ''}">${esc(e.kind)}</span></td>
      <td>${esc(e.msg)}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">暂无变更</td></tr>'}
    </tbody></table>
  </div>`;
}

function renderDetail() {
  const d = S.data;
  if (!d) { app.innerHTML = '<div class="empty">加载中…</div>'; return; }
  const host = d.host || {};
  const head = `<div class="dhead">
    <a href="#/" class="ghost">← 总览</a>
    <h1>${esc(d.name)}</h1>
    <span class="pill ${d.online ? 'ok' : 'bad'}">${d.online ? '在线' : '离线'}</span>
    <span class="meta">${esc(host.ip || '')} · ${esc((host.os || '').replace(' GNU/Linux', ''))} · ${esc(host.kernel || '')}</span>
    <span class="meta" style="margin-left:auto">${d.ts ? '更新于 ' + ago(d.ts) : ''}</span>
  </div>`;
  if (d.empty) {
    app.innerHTML = head + `<div class="card empty"><b>还没有收到数据</b>
      检查 Agent 是否运行：systemctl status vpsmon-agent</div>`;
    return;
  }
  const body = S.tab === 'sec' ? tabSec(d) : S.tab === 'upd' ? tabUpd(d)
    : S.tab === 'ports' ? tabPorts(d) : S.tab === 'cron' ? tabCron(d)
      : S.tab === 'hist' ? tabHist(d) : tabOverview(d);
  app.innerHTML = head + tabsHTML() + body;
}

/* ---------------- 告警 ---------------- */
function renderAlerts() {
  const d = S.alerts;
  if (!d) { app.innerHTML = '<div class="empty">加载中…</div>'; return; }
  let list = d.alerts || [];
  if (S.alertFilter === 'open') list = list.filter((a) => !a.resolved);
  app.innerHTML = `
  <div class="toolbar">
    <div class="sec-title" style="margin:0"><h2>告警</h2><span>未处理 ${d.open} 条</span></div>
    <div class="grow"></div>
    <button class="ghost" data-act="afilter" data-f="open" style="${S.alertFilter === 'open' ? 'border-color:#a9c4f5;color:#1f6feb' : ''}">未处理</button>
    <button class="ghost" data-act="afilter" data-f="all" style="${S.alertFilter === 'all' ? 'border-color:#a9c4f5;color:#1f6feb' : ''}">全部</button>
    <button class="ghost" data-act="ackall">全部标记已读</button>
  </div>
  <div class="card">${list.map((a) => `
    <div class="alert-row">
      <i class="lv ${a.level}"></i>
      <div style="flex:1;min-width:0">
        <div class="tt">${esc(a.sname || a.server_id)} · ${esc(a.title)}</div>
        <div class="dd">${esc(a.detail)}</div>
        <div class="mt"><span>${new Date(a.ts * 1000).toLocaleString('zh-CN', { hour12: false })}</span>
          <span>${a.resolved ? '已恢复' : '进行中'}</span>
          ${a.acked ? '<span>已读</span>' : ''}</div>
      </div>
      ${!a.acked && !a.resolved ? `<button class="ghost" data-act="ack" data-id="${a.id}">标记已读</button>` : ''}
    </div>`).join('') || '<div class="empty" style="padding:40px">没有告警，一切正常</div>'}
  </div>`;
}

/* ---------------- 设置 ---------------- */
function renderSettings() {
  const d = S.settings;
  if (!d) { app.innerHTML = '<div class="empty">加载中…</div>'; return; }
  const ch = d.channels || {};
  const sec = S.sec || { totp_on: false, logins: [] };
  const th = d.thresholds || {};
  const ns = S.newServer;
  const on = (o) => (o && o.enabled ? 'checked' : '');
  app.innerHTML = `
  <div class="sec-title" style="margin-top:0"><h2>监控服务器</h2><span>${d.servers.length} 台 · 卸载 Agent 后卡片会转为离线</span></div>
  <div class="card">
    <table><thead><tr><th>名称</th><th>备注</th><th>月流量配额</th><th>云安全组</th><th>最后上报</th><th></th></tr></thead><tbody>
    ${d.servers.map((s) => `<tr>
      <td><b>${esc(s.name)}</b></td>
      <td class="muted">${esc(s.note || '—')}</td>
      <td class="muted">${s.quota_gb ? s.quota_gb + ' GB' : '不限'}</td>
      <td><label class="inline-check"><input type="checkbox" data-act="flag" data-id="${s.id}" ${s.cloud_fw ? 'checked' : ''}> 已收口</label></td>
      <td class="muted">${ago(s.seen)}</td>
      <td style="white-space:nowrap;text-align:right">
        <button class="ghost" data-act="token" data-id="${s.id}">重发安装</button>
        <button class="btn danger sm" data-act="del" data-id="${s.id}">删除</button>
      </td></tr>`).join('') || '<tr><td colspan="6" class="muted">还没有服务器</td></tr>'}
    </tbody></table>
  </div>
  ${ns ? `<div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 8px"><h2>在 ${esc(ns.name)} 上执行</h2><span>以 root 运行，10 秒内出现数据</span></div>
    <div class="install">${esc(ns.install)}</div>
    <div style="margin-top:10px"><button class="btn sm" data-act="copy" data-text="${esc(ns.install)}">复制命令</button>
    <span class="hint" style="margin-left:8px">这条命令含密钥，只显示这一次；丢了点「重发安装」重新生成。</span></div>
  </div>` : ''}

  <div class="row" style="margin-top:14px;align-items:flex-start">
    <div class="card panel" style="flex:1 1 460px">
      <div class="sec-title" style="margin:0 0 12px"><h2>添加服务器</h2><span>生成一次性安装命令</span></div>
      <div class="row">
        <label class="f"><span>名称</span><input id="ns-name" placeholder="香港-1"></label>
        <label class="f"><span>分组（可选）</span><input id="ns-grp" placeholder="甲骨文"></label>
      </div>
      <div class="row">
        <label class="f"><span>备注（可选）</span><input id="ns-note" placeholder="2C2G 40G 节点"></label>
        <label class="f"><span>月流量配额 GB（0 不限）</span><input id="ns-quota" type="number" value="0"></label>
      </div>
      <button class="btn" data-act="add">生成安装命令</button>
    </div>
    <div class="card panel" style="flex:1 1 380px">
      <div class="sec-title" style="margin:0 0 12px"><h2>账号安全</h2><span>面板只有一个管理员</span></div>
      <div class="row">
        <label class="f"><span>原密码</span><input id="pw-old" type="password"></label>
        <label class="f"><span>新密码（至少 8 位）</span><input id="pw-new" type="password"></label>
      </div>
      <button class="btn" data-act="pw">修改密码</button>
      <div class="sep"></div>
      <div class="kv" style="grid-template-columns:1fr 1fr">
        <div><b>两步验证</b><span>${sec.totp_on ? '<span class="tag green">已开启</span>' : '<span class="tag">未开启</span>'}</span></div>
        <div><b>当前会话</b><span>7 天后自动过期</span></div>
      </div>
      ${sec.totp_on
      ? `<div class="row" style="margin-top:10px"><label class="f"><span>关闭需验证密码</span>
           <input id="totp-pw" type="password"></label></div>
         <button class="ghost" data-act="totpoff">关闭两步验证</button>`
      : (S.totp ? `<div class="totpbox">
           <div class="hint">用验证器 App（1Password / Google Authenticator / 微软 Authenticator）添加下面的密钥，然后输入一次当前动态码完成绑定。</div>
           <div class="totpkey"><span class="mono" id="totp-secret">${esc(S.totp.secret)}</span>
             <button class="ghost" data-act="copy" data-text="${esc(S.totp.secret)}">复制</button></div>
           <div class="hint mono" style="word-break:break-all;font-size:11px">${esc(S.totp.uri)}</div>
           <div class="row"><label class="f"><span>6 位动态码</span>
             <input id="totp-code" inputmode="numeric" placeholder="123456"></label></div>
           <button class="btn" data-act="totpenable">启用</button>
         </div>`
        : `<button class="ghost" data-act="totpsetup" style="margin-top:10px">开启两步验证</button>`)}
      <div class="sep"></div>
      <div class="hint" style="margin-bottom:6px">最近登录</div>
      <div class="loginlog">
        ${(sec.logins || []).map((l) => `<div><span class="muted">${new Date(l.ts * 1000).toLocaleString('zh-CN', { hour12: false })}</span>
          <span class="${l.level === 'warning' ? 'warn' : ''}">${esc(l.msg)}</span></div>`).join('') || '<div class="muted">暂无记录</div>'}
      </div>
      <div class="sep"></div>
      <div class="hint">版本 v${esc(d.version)} · <a href="/api/export" target="_blank">导出全部数据</a>
        <br>忘记密码：<code>python3 server/run.py --password 新密码</code>
        <br>手机丢了：<code>python3 server/run.py --totp-reset</code></div>
    </div>
  </div>

  <div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 12px"><h2>告警阈值</h2><span>触发后推到下面的通知渠道，恢复时会自动消警</span></div>
    <div class="row">
      <label class="f"><span>CPU 持续超过 %</span><input id="th-cpu" type="number" value="${th.cpu}"></label>
      <label class="f"><span>连续采样次数</span><input id="th-sus" type="number" value="${th.cpu_sustain}"></label>
      <label class="f"><span>内存超过 %</span><input id="th-mem" type="number" value="${th.mem}"></label>
      <label class="f"><span>磁盘超过 %</span><input id="th-disk" type="number" value="${th.disk}"></label>
      <label class="f"><span>离线判定（秒）</span><input id="th-off" type="number" value="${th.offline}"></label>
      <label class="f"><span>证书剩余天数</span><input id="th-cert" type="number" value="${th.cert}"></label>
      <label class="f"><span>流量配额预警 %</span><input id="th-tr" type="number" value="${th.traffic}"></label>
      <label class="f"><span>安全评分低于</span><input id="th-score" type="number" value="${th.score}"></label>
    </div>
    <button class="btn" data-act="save-th">保存阈值</button>
  </div>

  <div class="card panel" style="margin-top:14px">
    <div class="sec-title" style="margin:0 0 12px"><h2>通知渠道</h2><span>只推新告警，避免刷屏</span></div>
    <div class="chline"><label><input type="checkbox" id="ch-tg-on" ${on(ch.telegram)}> Telegram</label>
      <input id="ch-tg-token" placeholder="Bot Token" value="${esc(ch.telegram && ch.telegram.token || '')}">
      <input id="ch-tg-chat" placeholder="Chat ID" value="${esc(ch.telegram && ch.telegram.chat_id || '')}" style="max-width:150px">
      <button class="ghost" data-act="test" data-ch="telegram">测试</button></div>
    <div class="chline"><label><input type="checkbox" id="ch-wc-on" ${on(ch.wecom)}> 企业微信</label>
      <input id="ch-wc-url" placeholder="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=..." value="${esc(ch.wecom && ch.wecom.webhook || '')}">
      <button class="ghost" data-act="test" data-ch="wecom">测试</button></div>
    <div class="chline"><label><input type="checkbox" id="ch-bark-on" ${on(ch.bark)}> Bark</label>
      <input id="ch-bark-url" placeholder="https://api.day.app/你的key" value="${esc(ch.bark && ch.bark.url || '')}">
      <button class="ghost" data-act="test" data-ch="bark">测试</button></div>
    <div class="chline"><label><input type="checkbox" id="ch-wh-on" ${on(ch.webhook)}> 自定义 Webhook</label>
      <input id="ch-wh-url" placeholder="https://your-endpoint" value="${esc(ch.webhook && ch.webhook.url || '')}">
      <button class="ghost" data-act="test" data-ch="webhook">测试</button></div>
    <div style="margin-top:6px"><button class="btn" data-act="save-ch">保存渠道</button></div>
    <div class="hint" style="margin-top:10px">先保存再测试。Telegram 需要服务器能直连 api.telegram.org，国内机器一般不行。</div>
  </div>`;
}

/* ---------------- 路由与刷新 ---------------- */
function route() {
  const h = location.hash.replace(/^#/, '') || '/';
  if (h.indexOf('/s/') === 0) { S.view = 'detail'; S.id = h.slice(3); }
  else if (h.indexOf('/alerts') === 0) S.view = 'alerts';
  else if (h.indexOf('/settings') === 0) S.view = 'settings';
  else S.view = 'overview';
  load(true);
}

function sigOf(v, d) {
  if (!d) return '';
  if (v === 'overview') return JSON.stringify((d.servers || []).map((s) =>
    [s.id, s.ts, s.online, s.score, s.cpu && s.cpu.pct, s.mem && s.mem.pct, s.disk && s.disk.pct, s.alerts]));
  if (v === 'detail') return [d.ts, d.checks && d.checks.score, (d.ports || []).length,
    (d.events || []).length, (d.certs || []).length].join('|');
  if (v === 'alerts') return (d.alerts || []).map((a) => a.id + (a.acked ? 'a' : '')).join(',');
  return '';
}

async function load(reset) {
  try {
    if (S.view === 'overview') {
      const d = await api('/api/overview');
      const sg = sigOf('overview', d);
      S.ov = d;
      if (!reset && sg === S.sig) { renderTop(); return; }
      S.sig = sg; renderTop(); renderOverview();
    } else if (S.view === 'detail') {
      const d = await api('/api/server/' + S.id);
      const sg = sigOf('detail', d);
      S.data = d;
      if (reset) { S.tab = 'overview'; S.sig = ''; }
      if (!reset && sg === S.sig) { renderTop(); return; }
      S.sig = sg; renderTop(); renderDetail();
    } else if (S.view === 'alerts') {
      const d = await api('/api/alerts');
      const sg = sigOf('alerts', d);
      S.alerts = d;
      S.ov = S.ov || await api('/api/overview');
      if (!reset && sg === S.sig) { renderTop(); return; }
      S.sig = sg; renderTop(); renderAlerts();
    } else if (S.view === 'settings') {
      S.settings = await api('/api/settings');
      S.sec = await api('/api/security').catch(() => ({ totp_on: false, logins: [] }));
      renderTop(); renderSettings();
    }
  } catch (e) {
    if (e.message !== '未登录') app.innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}

let lastInteract = 0;
document.addEventListener('pointerdown', () => { lastInteract = Date.now(); }, true);
function poll() {
  const tag = document.activeElement && document.activeElement.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
  if (Date.now() - lastInteract < 1500) return;
  if (S.view === 'settings') return;
  load(false);
}

/* ---------------- 交互 ---------------- */
document.addEventListener('click', async (ev) => {
  const el = ev.target.closest('[data-act]');
  if (!el) return;
  const act = el.dataset.act;

  if (act === 'open') { location.hash = '#/s/' + el.dataset.id; return; }
  if (act === 'showsec' || act === 'hidesec' || act === 'togglesec') {
    S.showSec = act === 'togglesec' ? !S.showSec : act === 'showsec';
    localStorage.setItem('vpsmon_showsec', S.showSec ? '1' : '0');
    if (S.view === 'overview') renderOverview();
    return;
  }
  if (act === 'tab') { S.tab = el.dataset.tab; renderDetail(); window.scrollTo({ top: 0 }); return; }
  if (act === 'copy') { copy(el.dataset.text); return; }
  if (act === 'logout') {
    await api('/api/logout', {}).catch(() => { });
    location.href = '/login'; return;
  }
  if (act === 'afilter') { S.alertFilter = el.dataset.f; renderAlerts(); return; }
  if (act === 'ack') { await api('/api/alerts/ack', { id: +el.dataset.id }); S.alerts = await api('/api/alerts'); renderAlerts(); return; }
  if (act === 'ackall') { await api('/api/alerts/ack', { all: true }); S.alerts = await api('/api/alerts'); renderAlerts(); return; }

  if (act === 'add') {
    const name = $('#ns-name').value.trim();
    if (!name) return toast('请填写名称');
    try {
      const r = await api('/api/servers', {
        name, grp: $('#ns-grp').value.trim(), note: $('#ns-note').value.trim(),
        quota_gb: +$('#ns-quota').value || 0
      });
      S.newServer = { name, install: r.install };
      S.settings = await api('/api/settings');
      renderSettings();
      toast('已创建，复制命令到 VPS 执行');
    } catch (e) { toast(e.message); }
    return;
  }
  if (act === 'del') {
    if (!confirm('删除后该机器的历史数据一并清除，确定？')) return;
    await api('/api/server/' + el.dataset.id + '/delete', {});
    S.settings = await api('/api/settings'); renderSettings(); toast('已删除'); return;
  }
  if (act === 'token') {
    if (!confirm('重新生成后旧命令立即失效，Agent 需要重新安装。继续？')) return;
    const r = await api('/api/server/' + el.dataset.id + '/token', {});
    S.newServer = { name: r.install.split('--name ')[1] || '服务器', install: r.install };
    renderSettings(); toast('已生成新安装命令'); return;
  }
  if (act === 'save-th') {
    const th = {
      cpu: +$('#th-cpu').value, cpu_sustain: +$('#th-sus').value, mem: +$('#th-mem').value,
      disk: +$('#th-disk').value, offline: +$('#th-off').value, cert: +$('#th-cert').value,
      traffic: +$('#th-tr').value, score: +$('#th-score').value
    };
    await api('/api/settings', { thresholds: th }); toast('阈值已保存'); return;
  }
  if (act === 'save-ch') {
    const channels = {
      telegram: { enabled: $('#ch-tg-on').checked, token: $('#ch-tg-token').value.trim(), chat_id: $('#ch-tg-chat').value.trim() },
      wecom: { enabled: $('#ch-wc-on').checked, webhook: $('#ch-wc-url').value.trim() },
      bark: { enabled: $('#ch-bark-on').checked, url: $('#ch-bark-url').value.trim() },
      webhook: { enabled: $('#ch-wh-on').checked, url: $('#ch-wh-url').value.trim() }
    };
    await api('/api/settings', { channels }); toast('渠道已保存'); return;
  }
  if (act === 'test') {
    const r = await api('/api/test-channel', { name: el.dataset.ch });
    toast(r.ok ? '测试消息已发出' : '发送失败，检查配置或网络'); return;
  }
  if (act === 'totpsetup') {
    try { S.totp = await api('/api/totp/setup', {}); renderSettings(); }
    catch (e) { toast(e.message); }
    return;
  }
  if (act === 'totpenable') {
    const code = ($('#totp-code') || {}).value || '';
    try {
      await api('/api/totp/enable', { code });
      S.totp = null;
      S.sec = await api('/api/security');
      renderSettings(); toast('两步验证已开启');
    } catch (e) { toast(e.message); }
    return;
  }
  if (act === 'totpoff') {
    const password = ($('#totp-pw') || {}).value || '';
    try {
      await api('/api/totp/disable', { password });
      S.sec = await api('/api/security');
      renderSettings(); toast('两步验证已关闭');
    } catch (e) { toast(e.message); }
    return;
  }
  if (act === 'pw') {
    try {
      await api('/api/password', { old: $('#pw-old').value, new: $('#pw-new').value });
      toast('密码已修改'); $('#pw-old').value = ''; $('#pw-new').value = '';
    } catch (e) { toast(e.message); }
    return;
  }
});

document.addEventListener('change', async (ev) => {
  const el = ev.target.closest('[data-act="flag"]');
  if (!el) return;
  await api('/api/server/' + el.dataset.id, { cloud_fw: el.checked });
  toast(el.checked ? '已标记为云安全组收口' : '已取消标注');
});

window.addEventListener('hashchange', route);
route();
S.timer = setInterval(poll, 5000);
