const f = document.getElementById('f'), err = document.getElementById('err'), go = document.getElementById('go');
const codeWrap = document.getElementById('code-wrap'), codeInput = document.getElementById('code');
const notice = document.getElementById('notice'), pwInput = document.getElementById('pw');

// 刚改完密码跳过来：禁用浏览器自动填充，避免密码管理器把旧密码塞进来
if (/[?&]relogin=1/.test(location.search)) {
  notice.style.display = 'block';
  notice.innerHTML = '<b>密码已修改</b>，请用新密码重新登录。<br>旧密码在 30 分钟内仍可登录，之后自动失效。';
  pwInput.setAttribute('autocomplete', 'off');
  pwInput.value = '';
  pwInput.focus();
}

f.addEventListener('submit', async (e) => {
  e.preventDefault();
  go.disabled = true; go.textContent = '登录中…'; err.style.display = 'none';
  try {
    const r = await fetch('/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: f.username.value, password: f.password.value,
        code: codeInput ? codeInput.value : ''
      })
    });
    const d = await r.json().catch(() => ({}));
    if (r.ok) { location.href = '/'; return; }
    if (d.need_totp) {
      codeWrap.style.display = 'block';
      codeInput.focus();
      throw new Error(d.error || '请输入两步验证动态码');
    }
    throw new Error(d.error || '登录失败');
  } catch (e2) {
    err.textContent = e2.message; err.style.display = 'block';
  }
  go.disabled = false; go.textContent = '进入面板';
});
