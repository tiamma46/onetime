#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VPS 监控 Agent（Linux，仅标准库）
采集资源、SSH、防火墙、fail2ban、端口、定时任务、BBR、证书，主动上报到监控端。
"""

import glob
import hashlib
import json
import os
import re
import socket
import ssl
import subprocess
import sys
import time
import urllib.request

VER = "1.1.0"
CONF_PATH = "/etc/vpsmon/agent.json"
STATE_PATH = "/var/lib/vpsmon/state.json"
SPOOL_PATH = "/var/lib/vpsmon/spool.jsonl"

MINER_NAMES = ("kinsing", "kdevtmpfsi", "xmrig", "minerd", "kthreaddi", "sysupdate",
               "dbus-daem0n", "kworkerds", "watchbog", "cnrig")
KEEPALIVE_KW = ("keepalive", "keep-alive", "keep_alive", "保活", "oracle", "stress-ng",
                "dd if=/dev/zero", "while true", "while :", "yes >", "cpulimit",
                "sleep 60", "not-active", "防回收", "wakeup")

# 安全影响最大的几个组件：装没装补丁直接决定会不会被打
WATCH_PKGS = [
    ("openssh-server", "SSH 服务"), ("openssl", "OpenSSL"), ("nginx", "nginx"),
    ("docker-ce", "Docker"), ("fail2ban", "Fail2ban"), ("mysql-server", "MySQL"),
    ("mariadb-server", "MariaDB"), ("postgresql", "PostgreSQL"), ("redis-server", "Redis"),
]


# ---------------- 基础 ----------------

def sh(cmd, timeout=4, shell=False):
    try:
        p = subprocess.run(cmd if shell else cmd.split(), shell=shell,
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           timeout=timeout)
        return p.stdout.decode("utf-8", "replace").strip()
    except Exception:
        return ""


def read(path, default=""):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception:
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def write_json(path, obj):
    try:
        d = os.path.dirname(path)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(obj, f)
        os.replace(tmp, path)
    except Exception:
        pass


def num(v, d=0.0):
    try:
        return float(v)
    except Exception:
        return d


# ---------------- 采集：主机 ----------------

def host_info(state):
    uname = os.uname() if hasattr(os, "uname") else None
    os_name = ""
    os_id = ""
    os_ver = ""
    for line in read("/etc/os-release").splitlines():
        if line.startswith("PRETTY_NAME="):
            os_name = line.split("=", 1)[1].strip().strip('"')
        elif line.startswith("ID="):
            os_id = line.split("=", 1)[1].strip().strip('"').lower()
        elif line.startswith("VERSION_ID="):
            os_ver = line.split("=", 1)[1].strip().strip('"')
    if not os_id and os_name:
        low = os_name.lower()
        for k in ("ubuntu", "debian", "centos", "fedora", "alpine", "rocky", "almalinux"):
            if k in low:
                os_id = k
    model = ""
    cores = os.cpu_count() or 1
    threads = cores
    for line in read("/proc/cpuinfo").splitlines():
        if line.startswith("model name") and not model:
            model = line.split(":", 1)[1].strip()
        if line.startswith("cpu cores") and "phys" not in state:
            try:
                state["phys"] = int(line.split(":")[1])
            except Exception:
                pass
    physical = state.get("phys") or cores
    virt = sh("systemd-detect-virt")
    if not virt or virt == "none":
        virt = ""
    ip = ""
    out = sh("ip -4 route get 1.1.1.1")
    m = re.search(r"src (\d+\.\d+\.\d+\.\d+)", out)
    if m:
        ip = m.group(1)
    boot = 0.0
    try:
        boot = float(read("/proc/stat").split("btime")[1].split()[0])
    except Exception:
        pass
    up = 0
    try:
        up = int(float(read("/proc/uptime").split()[0]))
    except Exception:
        pass
    return {
        "hostname": socket.gethostname(),
        "os": os_name or (uname.sysname if uname else "Linux"),
        "os_id": os_id,
        "os_ver": os_ver,
        "kernel": uname.release if uname else "",
        "arch": uname.machine if uname else "",
        "virt": virt,
        "cpu_model": model,
        "cores": physical,
        "threads": threads,
        "ip": ip,
        "boot_ts": int(boot),
        "uptime": int(time.time() - boot) if boot else up,
        "vendor": read("/sys/class/dmi/id/sys_vendor").strip(),
    }


def cpu_info(state):
    lines = read("/proc/stat").splitlines()
    if not lines:
        try:
            ld = list(os.getloadavg())
        except Exception:
            ld = [0.0, 0.0, 0.0]
        return {"pct": 0.0, "load1": ld[0], "load5": ld[1], "load15": ld[2],
                "procs": 0, "top": []}
    line = lines[0].split()
    vals = [int(x) for x in line[1:9]]
    idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
    total = sum(vals)
    prev = state.get("cpu") or {}
    pct = 0.0
    if prev.get("total") and total > prev["total"]:
        dt = total - prev["total"]
        di = idle - prev.get("idle", 0)
        pct = max(0.0, min(100.0, (dt - di) * 100.0 / dt))
    state["cpu"] = {"total": total, "idle": idle}
    load = [0.0, 0.0, 0.0]
    try:
        load = [float(x) for x in read("/proc/loadavg").split()[:3]]
    except Exception:
        pass
    procs = 0
    try:
        procs = sum(1 for d in os.listdir("/proc") if d.isdigit())
    except Exception:
        pass
    top = []
    out = sh("ps -eo pid,comm,pcpu,pmem,rss,args --no-headers --sort=-pcpu")
    for ln in out.splitlines()[:6]:
        parts = ln.split(None, 5)
        if len(parts) < 6:
            continue
        top.append({"pid": parts[0], "name": parts[1], "cpu": num(parts[2]),
                    "mem": num(parts[3]), "rss": num(parts[4]) * 1024,
                    "cmd": parts[5][:160]})
    return {"pct": round(pct, 1), "load1": load[0], "load5": load[1], "load15": load[2],
            "procs": procs, "top": top}


def mem_info():
    info = {}
    for ln in read("/proc/meminfo").splitlines():
        k, _, v = ln.partition(":")
        info[k] = num(v.split()[0]) * 1024 if v.split() else 0
    total = info.get("MemTotal", 0)
    avail = info.get("MemAvailable", info.get("MemFree", 0))
    used = max(0, total - avail)
    cached = info.get("Cached", 0) + info.get("Buffers", 0)
    st = info.get("SwapTotal", 0)
    sf = info.get("SwapFree", 0)
    return ({"total": int(total), "used": int(used), "avail": int(avail),
             "cached": int(cached), "pct": round(used * 100.0 / total, 1) if total else 0},
            {"total": int(st), "used": int(st - sf),
             "pct": round((st - sf) * 100.0 / st, 1) if st else 0})


def disk_info():
    out = []
    seen = set()
    fs_ok = ("ext2", "ext3", "ext4", "xfs", "btrfs", "zfs", "f2fs", "vfat", "ntfs", "overlay")
    for ln in read("/proc/mounts").splitlines():
        parts = ln.split()
        if len(parts) < 3:
            continue
        dev, mnt, fs = parts[0], parts[1].replace("\\040", " "), parts[2]
        if fs not in fs_ok:
            continue
        if dev in seen or "/snap/" in mnt or mnt.startswith("/var/lib/docker/"):
            continue
        try:
            st = os.statvfs(mnt)
        except Exception:
            continue
        total = st.f_blocks * st.f_frsize
        free = st.f_bfree * st.f_frsize
        if total <= 0:
            continue
        seen.add(dev)
        used = total - free
        inode_pct = 0.0
        if st.f_files:
            inode_pct = round((st.f_files - st.f_ffree) * 100.0 / st.f_files, 1)
        out.append({"mount": mnt, "fs": fs, "device": dev, "total": int(total),
                    "used": int(used), "free": int(free),
                    "pct": round(used * 100.0 / total, 1), "inode_pct": inode_pct})
    out.sort(key=lambda d: (d["mount"] != "/", d["mount"]))
    return out[:8]


def net_info(state):
    rx = tx = 0
    best = ""
    for ln in read("/proc/net/dev").splitlines()[2:]:
        name, _, rest = ln.partition(":")
        if name.strip() == "lo":
            continue
        f = rest.split()
        if len(f) < 9:
            continue
        r, t = num(f[0]), num(f[8])
        rx += r
        tx += t
        if not best and r + t > 0:
            best = name.strip()
    prev = state.get("net") or {}
    now = time.time()
    dt = max(1.0, now - prev.get("ts", now - 10))
    rx_bps = max(0, (rx - prev.get("rx", rx)) / dt) if prev else 0
    tx_bps = max(0, (tx - prev.get("tx", tx)) / dt) if prev else 0
    state["net"] = {"rx": rx, "tx": tx, "ts": now}

    month = time.strftime("%Y-%m")
    if state.get("month") != month:
        state["month"] = month
        state["month_rx"] = 0
        state["month_tx"] = 0
    if prev:
        state["month_rx"] = state.get("month_rx", 0) + max(0, rx - prev.get("rx", rx))
        state["month_tx"] = state.get("month_tx", 0) + max(0, tx - prev.get("tx", tx))

    estab = conns = 0
    for f in ("/proc/net/tcp", "/proc/net/tcp6"):
        for ln in read(f).splitlines()[1:]:
            p = ln.split()
            if len(p) < 4:
                continue
            conns += 1
            if p[3] == "01":
                estab += 1
    return {"iface": best, "rx_bps": int(rx_bps), "tx_bps": int(tx_bps),
            "rx_total": int(rx), "tx_total": int(tx),
            "month_rx": int(state.get("month_rx", 0)),
            "month_tx": int(state.get("month_tx", 0)),
            "conns": conns, "estab": estab}


# ---------------- 采集：安全 ----------------

def ssh_info():
    out = {"source": "sshd_config"}
    txt = sh("sshd -T", timeout=5)
    if txt and "passwordauthentication" in txt:
        out["source"] = "sshd -T"
        for ln in txt.splitlines():
            k, _, v = ln.partition(" ")
            k = k.strip().lower()
            v = v.strip()
            if k == "passwordauthentication":
                out["password_auth"] = v
            elif k == "permitrootlogin":
                out["root_login"] = v
            elif k == "port":
                out.setdefault("ports", []).append(v)
            elif k == "maxauthtries":
                out["max_auth"] = v
            elif k == "pubkeyauthentication":
                out["pubkey"] = v
            elif k == "permitemptypasswords":
                out["permit_empty"] = v
        if out.get("ports"):
            out["port"] = int(out["ports"][0])
        return out
    # 退回配置文件解析
    cfg = read("/etc/ssh/sshd_config")
    for chunk in glob.glob("/etc/ssh/sshd_config.d/*.conf"):
        cfg += "\n" + read(chunk)
    for ln in cfg.splitlines():
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        parts = ln.split(None, 1)
        if len(parts) < 2:
            continue
        k = parts[0].lower()
        v = parts[1].split("#")[0].strip()
        if k == "passwordauthentication":
            out["password_auth"] = v
        elif k == "permitrootlogin":
            out["root_login"] = v
        elif k == "port":
            out["port"] = int(v) if v.isdigit() else 22
        elif k == "maxauthtries":
            out["max_auth"] = v
        elif k == "pubkeyauthentication":
            out["pubkey"] = v
    out.setdefault("port", 22)
    return out


def fail2ban_info():
    exists = bool(sh("command -v fail2ban-client", shell=True)) or os.path.isdir("/etc/fail2ban")
    active_txt = sh("systemctl is-active fail2ban")
    active = active_txt.strip() == "active"
    jails = []
    if active:
        st = sh("fail2ban-client status", timeout=5)
        m = re.search(r"Jail list:\s*(.+)", st)
        if m:
            for name in [x.strip() for x in m.group(1).split(",") if x.strip()]:
                detail = sh("fail2ban-client status %s" % name, timeout=5)
                banned = re.search(r"Currently banned:\s*(\d+)", detail)
                total = re.search(r"Total banned:\s*(\d+)", detail)
                jails.append({"name": name,
                              "banned": int(banned.group(1)) if banned else 0,
                              "total": int(total.group(1)) if total else 0})
    return {"installed": exists, "active": active, "jails": jails}


def firewall_info():
    ufw = ""
    if sh("command -v ufw", shell=True):
        t = sh("ufw status", timeout=4)
        if "Status: active" in t:
            ufw = "active (%d 条规则)" % len([l for l in t.splitlines() if l.startswith(("allow", "deny", "reject", "Limit"))])
        elif "Status: inactive" in t:
            ufw = "inactive"
    fwd = ""
    if sh("command -v firewall-cmd", shell=True):
        s = sh("firewall-cmd --state", timeout=3)
        fwd = "running" if s.strip() == "running" else (s.strip() or "not running")
    ipt = 0
    if sh("command -v iptables", shell=True):
        s = sh("iptables -S", timeout=4)
        ipt = len([l for l in s.splitlines() if l.startswith("-A")])
    nft = 0
    if sh("command -v nft", shell=True):
        s = sh("nft list ruleset", timeout=4)
        nft = len([l for l in s.splitlines() if " " in l and not l.startswith("table")])
    default_in = ""
    s = sh("iptables -S INPUT", timeout=3)
    m = re.search(r"-P INPUT (\w+)", s)
    if m:
        default_in = m.group(1)
    return {"ufw": ufw, "firewalld": fwd, "iptables_rules": ipt, "nft_rules": nft,
            "default_in": default_in}


def updates_info():
    """补丁与软件更新体检。

    只读：apt list / dpkg-query / apt-cache policy 都是查询类命令，
    不会真的安装或升级任何东西。
    """
    mgr = ""
    for m, probe in (("apt", "command -v apt-get"), ("dnf", "command -v dnf"),
                     ("yum", "command -v yum")):
        if sh(probe, shell=True):
            mgr = m
            break

    out = {"mgr": mgr, "pending": None, "security": None, "pkgs": [],
           "kernel_running": "", "kernel_newest": "", "check_age_days": None,
           "auto": None, "source": "", "reboot_required":
           os.path.exists("/var/run/reboot-required")}

    # ---- 自动安全更新是否开启 ----
    a = read("/etc/apt/apt.conf.d/20auto-upgrades")
    if a:
        out["auto"] = 'Unattended-Upgrade "1"' in a
        out["source"] = "unattended-upgrades"
    elif os.path.exists("/etc/dnf/automatic.conf"):
        cfg = read("/etc/dnf/automatic.conf")
        out["auto"] = "apply_updates = yes" in cfg.replace(" ", " ")
        out["source"] = "dnf-automatic"

    # ---- 待安装补丁 ----
    if mgr == "apt":
        txt = sh("apt list --upgradable", timeout=20)
        lines = [l for l in txt.splitlines() if "upgradable from" in l]
        if txt or lines:
            out["pending"] = len(lines)
            out["security"] = sum(1 for l in lines if "-security" in l.split()[0])
    elif mgr in ("dnf", "yum"):
        txt = sh("%s -q check-update" % mgr, timeout=25)
        out["pending"] = len([l for l in txt.splitlines()
                              if l.strip() and not l.startswith(("Last metadata", "Obsoleting"))])
        sec = sh("%s -q updateinfo list security" % mgr, timeout=25)
        if sec:
            out["security"] = len([l for l in sec.splitlines() if l.strip()])

    # ---- 内核：运行版本 vs 已装最新版本 ----
    run = os.uname().release if hasattr(os, "uname") else ""
    out["kernel_running"] = run
    if mgr == "apt":
        vs = [os.path.basename(p).replace("vmlinuz-", "") for p in glob.glob("/boot/vmlinuz-*")]
        if vs:
            out["kernel_newest"] = sorted(vs, key=_vkey)[-1]
    elif mgr in ("dnf", "yum"):
        txt = sh("rpm -q kernel --last", timeout=8)
        first = txt.splitlines()[0] if txt.splitlines() else ""
        m = re.search(r"kernel-([^\s]+)", first)
        if m:
            out["kernel_newest"] = m.group(1)

    # ---- 软件源多久没刷新 ----
    stamps = ["/var/lib/apt/periodic/update-success-stamp", "/var/cache/apt/pkgcache.bin",
              "/var/cache/dnf", "/var/cache/yum"]
    for s in stamps:
        if os.path.exists(s):
            try:
                out["check_age_days"] = round((time.time() - os.path.getmtime(s)) / 86400.0, 1)
                break
            except Exception:
                pass

    # ---- 重要软件：已装版本 vs 仓库候选版本 ----
    if mgr == "apt":
        want = [n for n, _ in WATCH_PKGS]
        inst = {}
        txt = sh("dpkg-query -W -f=${Package},${Version} " + " ".join(want), timeout=10)
        for ln in txt.splitlines():
            if "," in ln:
                a2, b2 = ln.split(",", 1)
                inst[a2.strip()] = b2.strip()
        cand, cur = {}, ""
        for ln in sh("apt-cache policy " + " ".join(want), timeout=15).splitlines():
            if ln and not ln.startswith((" ", "\t")) and ln.rstrip().endswith(":"):
                cur = ln.rstrip()[:-1]
            elif cur and "Candidate:" in ln:
                cand[cur] = ln.split("Candidate:", 1)[1].strip()
        for name, label in WATCH_PKGS:
            if name not in inst:
                continue
            c = cand.get(name) or ""
            if not c or c == "(none)":
                continue
            out["pkgs"].append({"label": label, "pkg": name, "installed": inst[name],
                                "candidate": c, "upgradable": c != inst[name]})
    elif mgr in ("dnf", "yum"):
        for name, label in WATCH_PKGS:
            q = sh("rpm -q --qf %{VERSION}-%{RELEASE} " + name, timeout=6)
            if not q or "not installed" in q:
                continue
            c = sh("%s -q --available --qf %%{VERSION}-%%{RELEASE} %s" % (mgr, name), timeout=8)
            out["pkgs"].append({"label": label, "pkg": name, "installed": q,
                                "candidate": c or "", "upgradable": bool(c and c != q)})

    # 非包管理器装的常见组件（3x-ui / xray）单独补一条
    for cmd, label in (("xray", "Xray"), ("x-ui", "3x-ui")):
        if sh("command -v %s" % cmd, shell=True):
            v = sh("%s version" % cmd, timeout=5)
            m = re.search(r"(\d+\.\d+\.\d+)", v)
            if m:
                out["pkgs"].append({"label": label, "pkg": cmd, "installed": m.group(1),
                                    "candidate": "", "upgradable": False})
    return out


def _vkey(v):
    """把 5.15.0-105-generic 这类版本号变成可排序的元组。"""
    parts = re.split(r"[.\-]", v or "")
    out = []
    for p in parts:
        try:
            out.append(int(p))
        except Exception:
            out.append(0)
    return out


def time_info():
    s = sh("timedatectl show -p NTPSynchronized --value", timeout=3)
    synced = None
    if s.strip() in ("yes", "no"):
        synced = s.strip() == "yes"
    else:
        st = sh("timedatectl status", timeout=3)
        if "synchronized: yes" in st:
            synced = True
        elif "synchronized: no" in st:
            synced = False
    svc = ""
    for n in ("chronyd", "chrony", "systemd-timesyncd", "ntp", "ntpd"):
        if sh("systemctl is-active %s" % n) == "active":
            svc = n
            break
    return {"synced": synced, "service": svc}


def keys_info():
    files = ["/root/.ssh/authorized_keys"] + glob.glob("/home/*/.ssh/authorized_keys")
    fps = []
    used = []
    for f in files:
        if not os.path.isfile(f):
            continue
        used.append(f)
        for ln in read(f).splitlines():
            ln = ln.strip()
            if not ln or ln.startswith("#"):
                continue
            blob = ln.split()
            key = blob[1] if len(blob) > 1 else ln
            fps.append(hashlib.sha256(key.encode()).hexdigest()[:16])
    last = 0
    if used:
        try:
            last = int(max(os.path.getmtime(f) for f in used))
        except Exception:
            pass
    return {"count": len(fps), "fingerprints": fps, "files": used, "mtime": last}


def bbr_info():
    cc = read("/proc/sys/net/ipv4/tcp_congestion_control").strip() or "unknown"
    qdisc = read("/proc/sys/net/core/default_qdisc").strip()
    avail = read("/proc/sys/net/ipv4/tcp_available_congestion_control").split()
    return {"cc": cc, "qdisc": qdisc, "available": avail,
            "enabled": "bbr" in avail}


def suspicious_info():
    out = []
    try:
        entries = os.listdir("/proc")
    except Exception:
        return out
    for d in entries:
        if not d.isdigit():
            continue
        try:
            cmd = read("/proc/%s/cmdline" % d).replace("\x00", " ").strip()
            name = read("/proc/%s/comm" % d).strip()
            exe = os.readlink("/proc/%s/exe" % d)
        except Exception:
            continue
        low = (cmd + " " + exe).lower()
        reason = ""
        if any(n in name.lower() for n in MINER_NAMES):
            reason = "进程名命中挖矿木马名单"
        elif exe.startswith(("/tmp/", "/dev/shm/", "/var/tmp/")):
            reason = "可执行文件位于临时目录"
        elif " (deleted)" in exe and "kworker" not in name:
            reason = "可执行文件已被删除（常见的驻留手法）"
        if reason:
            out.append({"pid": int(d), "name": name, "cmd": cmd[:120], "reason": reason})
    return out[:6]


# ---------------- 采集：端口 / 定时任务 ----------------

def ports_info():
    out = []
    txt = sh("ss -Htulnp", timeout=4)
    if txt:
        for ln in txt.splitlines():
            p = ln.split()
            if len(p) < 5:
                continue
            proto = p[0]
            local = p[4]
            if ":" not in local:
                continue
            addr, _, port = local.rpartition(":")
            name = ""
            m = re.search(r'users:\(\("([^"]+)"', ln)
            if m:
                name = m.group(1)
            out.append({"proto": proto, "addr": addr.strip("[]"), "port": int(port) if port.isdigit() else 0,
                        "proc": name, "exposed": addr.strip("[]") not in ("127.0.0.1", "::1")})
    else:
        txt = sh("netstat -tulnp", timeout=4)
        for ln in txt.splitlines():
            p = ln.split()
            if len(p) < 7 or p[0] not in ("tcp", "tcp6", "udp", "udp6"):
                continue
            local = p[3]
            addr, _, port = local.rpartition(":")
            prog = p[6].split("/")[-1] if "/" in p[6] else ""
            out.append({"proto": p[0][:3], "addr": addr.strip("[]"),
                        "port": int(port) if port.isdigit() else 0, "proc": prog,
                        "exposed": addr.strip("[]") not in ("127.0.0.1", "::1")})
    # 去重（ss 会同时给出 tcp/tcp6）
    seen = set()
    uniq = []
    for p in out:
        k = (p["proto"], p["port"], p["proc"])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(p)
    uniq.sort(key=lambda x: x["port"])
    return uniq[:80]


def cron_info():
    out = []

    def add(src, schedule, cmd):
        cmd = cmd.strip()
        if not cmd:
            return
        out.append({"src": src, "schedule": schedule, "cmd": cmd[:200],
                    "hash": hashlib.sha1((cmd + schedule).encode()).hexdigest()[:12]})

    txt = sh("crontab -l", timeout=4)
    for ln in txt.splitlines():
        ln = ln.strip()
        if not ln or ln.startswith("#") or "=" in ln.split()[0]:
            continue
        p = ln.split(None, 5)
        if len(p) >= 6:
            add("root crontab", " ".join(p[:5]), p[5])

    for path, src in [("/etc/crontab", "/etc/crontab")] + \
                     [(f, "/etc/cron.d") for f in glob.glob("/etc/cron.d/*")]:
        for ln in read(path).splitlines():
            ln = ln.strip()
            if not ln or ln.startswith("#") or "=" in ln.split()[0]:
                continue
            p = ln.split(None, 6)
            if len(p) >= 7:
                add(src, " ".join(p[:5]), p[6])
            elif len(p) == 6:
                add(src, " ".join(p[:5]), p[5])

    for f in glob.glob("/etc/cron.daily/*") + glob.glob("/etc/cron.hourly/*"):
        if os.path.isfile(f):
            add(os.path.basename(os.path.dirname(f)), "@periodic", f)
    return out[:40]


def timers_info():
    out = []
    txt = sh("systemctl list-timers --all --no-pager --no-legend", timeout=5)
    for ln in txt.splitlines():
        p = ln.split()
        if len(p) < 5:
            continue
        out.append({"name": p[-2] if p[-2].endswith(".timer") else p[-3],
                    "next": " ".join(p[:3]), "active": p[-1]})
    return out[:30]


def services_info():
    watch = ["nginx", "fail2ban", "docker", "ssh", "sshd", "x-ui", "xray", "cloudflared",
             "caddy", "1panel", "mysql", "mariadb", "postgresql", "redis-server", "cron"]
    out = []
    for n in watch:
        if not os.path.isdir("/run/systemd/system"):
            break
        st = sh("systemctl is-active %s" % n, timeout=3)
        if st in ("active", "failed", "inactive"):
            en = sh("systemctl is-enabled %s" % n, timeout=3)
            out.append({"name": n, "active": st == "active", "enabled": en == "enabled",
                        "state": st})
    return out


def docker_info():
    if not sh("command -v docker", shell=True):
        return []
    out = []
    txt = sh("docker ps -a --format '{{.Names}}\t{{.State}}\t{{.Image}}\t{{.Status}}'", timeout=6)
    for ln in txt.splitlines():
        p = ln.split("\t")
        if len(p) >= 3:
            out.append({"name": p[0], "state": p[1], "image": p[2],
                        "status": p[3] if len(p) > 3 else ""})
    return out[:20]


def keepalive_info(cron, timers, docker):
    evidence = []
    for c in cron:
        low = c["cmd"].lower()
        if any(k in low for k in KEEPALIVE_KW):
            evidence.append("cron(%s): %s" % (c["src"], c["cmd"][:90]))
    for t in timers:
        low = t["name"].lower()
        if any(k in low for k in ("keep", "alive", "保活")):
            evidence.append("timer: %s" % t["name"])
    ps = sh("ps -eo comm,args --no-headers")
    for ln in ps.splitlines():
        low = ln.lower()
        if "stress-ng" in low or low.startswith("yes ") or "keepalive" in low or "keep_alive" in low:
            evidence.append("进程: %s" % ln.strip()[:90])
            break
    return {"detected": bool(evidence), "evidence": evidence[:5]}


def certs_info(cfg):
    out = []
    paths = glob.glob("/etc/letsencrypt/live/*/fullchain.pem")
    paths += cfg.get("certs") or []
    for p in paths[:10]:
        try:
            d = ssl._ssl._test_decode_cert(p)  # noqa: SLF001 标准库私有但稳定
            from email.utils import mktime_tz, parsedate_tz
            exp = mktime_tz(parsedate_tz(d.get("notAfter")))
            days = int((exp - time.time()) // 86400)
            san = [v for k, v in d.get("subjectAltName", ()) if k == "DNS"]
            cn = ""
            for rdn in d.get("subject", ()):
                for k, v in rdn:
                    if k == "commonName":
                        cn = v
            out.append({"domain": (san[0] if san else cn) or os.path.basename(os.path.dirname(p)),
                        "days": days, "issuer": str(d.get("issuer")), "path": p})
        except Exception:
            continue
    return out


# ---------------- 上报 ----------------

def collect(state, cache, cfg):
    now = int(time.time())
    full = (now - cache.get("sec_ts", 0)) > 60 or "sec" not in cache
    if full or "host" not in cache:
        cache["host"] = host_info(state)
    host = dict(cache["host"])
    if host.get("boot_ts"):
        host["uptime"] = max(0, now - host["boot_ts"])
    payload = {
        "ver": VER, "ts": now,
        "host": host,
        "cpu": cpu_info(state),
        "net": net_info(state),
    }
    payload["mem"], payload["swap"] = mem_info()
    payload["disks"] = disk_info()

    if full:
        cron = cron_info()
        timers = timers_info()
        docker = docker_info()
        cache["cron"], cache["timers"], cache["docker"] = cron, timers, docker
        sec = cache.get("sec") or {}
        # 补丁查询较慢（apt list / apt-cache policy），30 分钟查一次足够
        if now - cache.get("upd_ts", 0) > 1800 or "updates" not in sec:
            sec["updates"] = updates_info()
            cache["upd_ts"] = now
        sec.update({
            "ssh": ssh_info(), "fail2ban": fail2ban_info(), "firewall": firewall_info(),
            "time": time_info(), "keys": keys_info(),
            "bbr": bbr_info(), "suspicious": suspicious_info(),
        })
        cache["sec"] = sec
        cache["ports"] = ports_info()
        cache["services"] = services_info()
        cache["sec_ts"] = now

    payload["sec"] = cache.get("sec") or {}
    payload["ports"] = cache.get("ports") or []
    payload["cron"] = cache.get("cron") or []
    payload["timers"] = cache.get("timers") or []
    payload["docker"] = cache.get("docker") or []
    payload["services"] = cache.get("services") or []
    payload["keepalive"] = keepalive_info(payload["cron"], payload["timers"], payload["docker"])
    payload["certs"] = certs_info(cfg)
    return payload


def post(url, token, payload, timeout=12):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url.rstrip("/") + "/api/ingest", data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("User-Agent", "vpsmon-agent/%s" % VER)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status == 200


def spool_save(payload):
    try:
        d = os.path.dirname(SPOOL_PATH)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        lines = read(SPOOL_PATH).splitlines()
        lines.append(json.dumps(payload, ensure_ascii=False))
        lines = lines[-120:]
        with open(SPOOL_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass


def spool_flush(url, token):
    try:
        if not os.path.isfile(SPOOL_PATH):
            return
        lines = [l for l in read(SPOOL_PATH).splitlines() if l.strip()]
        if not lines:
            return
        keep = []
        for i, ln in enumerate(lines):
            try:
                if post(url, token, json.loads(ln)):
                    continue
            except Exception:
                pass
            keep.extend(lines[i:])
            break
        with open(SPOOL_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(keep[-120:]) + ("\n" if keep else ""))
    except Exception:
        pass


def main():
    args = sys.argv[1:]
    cfg = {}
    if "--config" in args:
        cfg = read_json(args[args.index("--config") + 1], {})
    else:
        cfg = read_json(CONF_PATH, {})
    for i, a in enumerate(args):
        if a in ("--server", "--token", "--name") and i + 1 < len(args):
            cfg[a[2:]] = args[i + 1]
        if a == "--interval" and i + 1 < len(args):
            cfg["interval"] = int(args[i + 1])
    if not cfg.get("server") or not cfg.get("token"):
        print("缺少 --server / --token，或配置文件 %s" % CONF_PATH)
        return 2

    interval = int(cfg.get("interval") or 10)
    state = read_json(STATE_PATH, {})
    cache = {}
    once = "--once" in args

    if "--print" in args:
        print(json.dumps(collect(state, cache, cfg), ensure_ascii=False, indent=2))
        return 0

    print("vpsmon-agent %s -> %s（每 %ds）" % (VER, cfg["server"], interval))
    while True:
        try:
            payload = collect(state, cache, cfg)
            write_json(STATE_PATH, state)
            try:
                post(cfg["server"], cfg["token"], payload)
                spool_flush(cfg["server"], cfg["token"])
            except Exception as e:
                spool_save(payload)
                print("上报失败：%s（已本地缓存）" % e)
        except Exception as e:
            print("采集异常：%s" % e)
        if once:
            break
        time.sleep(interval)
    return 0


if __name__ == "__main__":
    sys.exit(main())
