# VPS智能监控平台

自托管的 VPS 状态与安全监控面板。每台机器装一个约 40KB 的 Agent 主动往外推数据，一台机器跑面板。

**零第三方依赖**（Python 3 标准库 + 原生前端），解压即跑，不需要 pip、Node、数据库服务。

![总览](test/shots/02-overview.png)

## 能看到什么

**总览**：每台服务器一张卡片 —— CPU / 内存 / 磁盘三行「百分比 + 双色进度条 + 已用/总量」，
下面是实时带宽、30 点趋势线和负载/在线时长。**备注**显示在名称下方，名称重复时靠它区分，
点卡片右侧「编辑」可随时改名/改备注（不用动 Agent）。
安全评分、防护标签、风险摘要默认**收起**，点「显示安全信息」才展开（防止截图把弱点带出去）。

**详情**（点卡片进入，六个页签）：

| 页签 | 内容 |
|---|---|
| 概览 | 资源实时曲线、负载、Swap、TCP 连接、本月流量、系统信息、Top 进程 |
| 安全体检 | 17 项检查逐条给结论 + 修复命令（可折叠、可复制），按「远程访问 / 入侵防护 / 补丁与更新 / 系统维护 / 网络优化」分组 |
| 更新与补丁 | 待装补丁数、安全补丁数、系统是否已 EOL、内核是否待重启、软件源多久没刷新、SSH/OpenSSL/nginx/Docker 等关键组件版本对比 |
| 端口与服务 | 监听端口 + 归属进程 + 是否公网可达 + 风险判定，系统服务、Docker 容器、证书到期 |
| 定时与保活 | crontab / systemd timer 全量列表，保活脚本检测，甲骨文免费实例「近 7 天平均 CPU 过低 + 无保活」回收风险提示 |
| 历史与变更 | 近 30 分钟（10 秒粒度）、近 72 小时（小时均值）、网络速率，端口 / 密钥 / 定时任务的变化留痕 |

**告警**：离线、CPU 持续高、内存、磁盘、证书到期、流量配额、新端口开放、SSH 密码登录、
高危端口暴露、**有未装的安全补丁**、评分过低。只推新告警，恢复自动消警，
支持 Telegram / 企业微信机器人 / Bark / 自定义 Webhook。

## 补丁与更新怎么判定

只看「有没有开自动更新」是不够的 —— 关了自动更新但手动打了补丁，和开了自动更新但从没跑成，
风险完全不同。所以这一项拆成六条：

| 检查项 | 权重 | 数据来源 |
|---|---|---|
| 安全补丁 | 10 | `apt list --upgradable` / `dnf updateinfo list security`，数出来自 `-security` 源的包 |
| 系统支持期 | 6 | `/etc/os-release` 的 ID + VERSION_ID 对照各发行版官方 EOL 表；已 EOL 直接判失败 |
| 自动安全更新 | 5 | unattended-upgrades / dnf-automatic 配置 |
| 重要软件更新 | 4 | `dpkg-query` 已装版本 vs `apt-cache policy` 仓库候选版本，比对 SSH、OpenSSL、nginx、Docker、Fail2ban、MySQL、Redis 等 |
| 内核版本 | 2 | 运行内核（`uname -r`）vs `/boot/vmlinuz-*` 里最新的那个，落后说明装了补丁但没重启 |
| 软件源刷新 | 2 | apt/dnf 包索引文件的 mtime，超过 7 天说明「可升级列表」本身已经不准 |

> 补丁查询要跑 `apt list` 和 `apt-cache policy`，比较慢，所以 Agent 里单独给了 30 分钟缓存，
> 资源类指标仍然 10 秒一次。

## 安全体检怎么判定

| 检查项 | 权重 | 判定依据 |
|---|---|---|
| SSH 密码登录 | 14 | `sshd -T`（失败回退解析 sshd_config），`PasswordAuthentication` |
| 主机防火墙 | 12 | ufw / firewalld / iptables 规则数 / nftables 规则数，四选一成立即通过；也可人工标注「已用云安全组」 |
| Fail2ban | 12 | 是否安装、是否运行、jail 列表、当前封禁数 |
| 高危端口暴露 | 10 | 3306/6379/27017/5432/9200/2375/3389 等是否监听 0.0.0.0；面板类进程暴露公网只记警告 |
| Root 直接登录 | 6 | `PermitRootLogin`，`prohibit-password` 只算警告 |
| 可疑进程 | 5 | 挖矿进程名名单、可执行文件在 /tmp 或 /dev/shm、exe 已被删除 |
| 授权密钥数量 | 4 | authorized_keys 条数，>3 提示清理 |
| SSH 端口 | 3 | 22 端口对公网开放记警告 |
| BBR | 3 | `tcp_congestion_control` + 内核可用算法 |
| 时间同步 | 2 | `timedatectl` NTPSynchronized |

评分 = 100 − Σ(权重 × 系数) ÷ Σ权重 × 100，失败 1.0、警告 0.5、读不到 0.15。
权重合计 100，加新检查项时按比例归一化，不用改别处。
≥90 优秀，75–89 良好，60–74 待改善，<60 危险。

**关于甲骨文云**：开荒手册里明确「系统内不启用 UFW，端口只在控制台安全组放行」，
所以单纯看 UFW 会全员误报。在「设置 → 监控服务器」勾上「已收口」，防火墙项直接按通过算。

## 三种部署方式

完整步骤见 [docs/部署与使用.md](docs/部署与使用.md)，这里给最短路径。

### A. 上传安装包（最稳，不依赖外网）

```bash
# 本机
scp vpsmon.tar.gz root@你的服务器:/root/
# 服务器上
tar xzf vpsmon.tar.gz && cd vpsmon && sudo bash install.sh
```

装完会打印面板地址和初始密码。

### B. 一句命令（把包放到任意静态地址后）

```bash
curl -fsSL https://你的地址/install.sh | sudo bash -s -- --pkg https://你的地址/vpsmon.tar.gz
```

tar 包和 install.sh 放在同一个能公网访问的地方即可（GitHub Release、对象存储、
自己另一台机器的 nginx、甚至某个已部署面板的 `/agent/` 目录）。

### C. Docker

```bash
cd deploy && docker compose up -d      # 只绑 127.0.0.1:8848，数据在 named volume
```

### 装完之后

1. `http://127.0.0.1:8848` 登录（或按下面的 HTTPS 方式对外）；
2. 进「设置 → 添加服务器」，复制生成的那行命令；
3. 到目标 VPS 上以 root 执行，10 秒内面板就会出现那台机器。

上 HTTPS 二选一：

```nginx
# Nginx + certbot，完整示例见 deploy/nginx.conf
location / {
    proxy_pass http://127.0.0.1:8848;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Host $host;   # 后端校验 Origin 要用
}
```

```bash
# 或者 Cloudflare Tunnel，不开任何入站端口
cloudflared tunnel route dns vpsmon vps.example.com
```

Agent 的 `--server` 填最终对外地址，走隧道也能上报（Agent 是主动出站）。

### 被监控的 VPS

```bash
curl -fsSL https://vps.example.com/agent/install.sh | sudo bash -s -- \
  --server https://vps.example.com --token <一次性TOKEN> --name 香港-1
```

安装脚本会：检查 python3（缺了自动装）→ 下载 agent.py 到 `/opt/vpsmon/` →
写配置 `/etc/vpsmon/agent.json`（0600）→ 注册 `vpsmon-agent.service` 并启动。

Agent 每 10 秒上报资源，每 60 秒做一次安全扫描，补丁信息 30 分钟一次。
上报失败会缓存到 `/var/lib/vpsmon/spool.jsonl`，恢复后连原始时间戳一起补传。

卸载 Agent：

```bash
sudo systemctl disable --now vpsmon-agent
sudo rm -rf /opt/vpsmon /etc/vpsmon /var/lib/vpsmon /etc/systemd/system/vpsmon-agent.service
```

## 目录

```
install.sh    面板一键安装（systemd）
uninstall.sh  卸载（保留 data）
server/
  run.py      HTTP 服务、路由、登录、上报接收、数据组装、安全头
  store.py    SQLite（服务器 / 快照 / 采样 / 小时聚合 / 事件 / 告警 / 会话）
  checks.py   体检项定义、评分、修复命令、端口风险、EOL 表
  alerts.py   快照差分、规则判定、离线扫描、通知推送
  web/        面板前端（原生 JS，无构建、无 CDN）
agent/
  agent.py    采集器（只读，不改系统配置）
  install.sh  Agent 一键安装
deploy/       systemd 单元、nginx 示例、Dockerfile、compose
docs/         设计方案、部署与使用、安全说明
test/         演示数据、冒烟测试（38 项）、截图脚本
data/         运行时生成：vpsmon.db、初始密码.txt
```

## 数据与备份

- 数据库只有一个文件：`data/vpsmon.db`（WAL 模式，热备直接 `cp` 也能用）。
- 采样保留 48 小时原始点、100 天小时聚合、30 天事件；后台每 10 分钟清理一次。
- 全量数据导出：`GET /api/export`（需登录）。
- 升级只覆盖代码目录，`data/` 不动；`install.sh` 重跑即为升级。

## 安全

见 [docs/安全说明.md](docs/安全说明.md)。要点：

- **Agent 只读、只出站**：不执行面板下发的任何命令，面板也没有「执行命令」的接口。
  拿下面板 ≠ 拿下服务器。
- 面板默认只监听 `127.0.0.1`，公网入口由 Nginx 或 Cloudflare Tunnel 提供。
- 登录：PBKDF2-SHA256 12 万轮加盐、HttpOnly + SameSite=Lax 会话、按 IP+账号锁定、
  可开 TOTP 两步验证；**改密后所有会话（含当前）立即失效，强制用新密码重登**，
  且 30 分钟内旧密码仍可登录一次作为容错（防手误把自己锁在外面），用新密码登录成功后宽限立即关闭。
- 响应头带 CSP / X-Frame-Options / Permissions-Policy，登录页无内联脚本。
- 跨站 POST 按 Origin 拒绝；上报接口按 token 做令牌桶限速；登录、改密、令牌轮换都有审计日志。

## 已知边界

- CPU 使用率是两次采样差值算的，进程重启后第一个点会是 0。
- 流量统计按网卡累计字节算自然月，重启不清零（状态落在 `/var/lib/vpsmon/state.json`），但**重装系统会清零**。
- 证书监控默认扫 `/etc/letsencrypt/live/*/fullchain.pem`，其它位置在 `agent.json` 里加 `"certs": ["/path/fullchain.pem"]`。
- 补丁数量依赖发行版仓库元数据；非 apt/dnf 系统（如 Alpine）这一组会显示「读取失败」。
- 告警暂不支持按机器静音/分组升级，够用但不算完整告警平台。
