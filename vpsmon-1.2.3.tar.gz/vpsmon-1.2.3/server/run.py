#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VPS智能监控平台 · 服务端
零第三方依赖：python3 server/run.py 即可运行。
"""

import argparse
import base64
import hashlib
import hmac
import json
import os
import struct
import re
import secrets
import ssl
import sys
import threading
import time
from datetime import datetime
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(HERE, "web")
VERSION = "1.2.3"

sys.path.insert(0, HERE)
import checks  # noqa: E402
import alerts  # noqa: E402
from store import Store  # noqa: E402

MIME = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png",
        ".ico": "image/x-icon", ".json": "application/json; charset=utf-8",
        ".woff2": "font/woff2"}

LOGIN_FAIL = {}
INGEST_BUCKET = {}
# 改密后旧密码的宽限时间（秒）：防止改完打错字把自己锁在面板外面
PW_GRACE = 30 * 60
CACHE = {"ov": (0, None)}
LOCK = threading.RLock()

# 收紧到只允许自身资源：没有内联脚本、不允许被 iframe 嵌入
CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data:; connect-src 'self'; font-src 'self'; "
       "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")


# ---------------- 工具 ----------------

def now_ts():
    return int(time.time())


def pw_hash(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 120000)
    return "%s$%s" % (salt, h.hex())


def pw_check(pw, stored):
    try:
        salt = stored.split("$", 1)[0]
        return hmac.compare_digest(pw_hash(pw, salt), stored)
    except Exception:
        return False


def tok_hash(t):
    return hashlib.sha256(t.encode()).hexdigest()


def totp_code(secret, t=None, step=30, digits=6):
    """RFC 6238 TOTP，用标准库实现，不引第三方包。"""
    try:
        pad = "=" * ((8 - len(secret) % 8) % 8)
        key = base64.b32decode(secret.upper() + pad)
        counter = int((t if t is not None else time.time()) // step)
        h = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
        o = h[-1] & 0x0F
        return "%0*d" % (digits, (struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % 10 ** digits)
    except Exception:
        return ""


def totp_verify(secret, code, window=1):
    code = (code or "").strip().replace(" ", "")
    if not secret or not code.isdigit():
        return False
    now = time.time()
    for w in range(-window, window + 1):
        if hmac.compare_digest(totp_code(secret, now + w * 30), code):
            return True
    return False


def allow_ingest(key, rate=5.0, cap=20):
    """令牌桶：防止有人拿一个合法 token 疯狂写库把磁盘灌满。"""
    now = time.time()
    if len(INGEST_BUCKET) > 5000:
        INGEST_BUCKET.clear()
    rec = INGEST_BUCKET.get(key)
    if not rec:
        INGEST_BUCKET[key] = [cap - 1, now]
        return True
    tokens = min(cap, rec[0] + (now - rec[1]) * rate)
    if tokens < 1:
        INGEST_BUCKET[key] = [tokens, now]
        return False
    INGEST_BUCKET[key] = [tokens - 1, now]
    return True


def audit(store, kind, level, msg):
    """安全相关的操作留痕，出事能倒查。"""
    try:
        store.add_event(None, kind, level, msg[:300])
    except Exception:
        pass


def human_bytes(n):
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return ("%.0f %s" % (n, u)) if u in ("B", "KB") else ("%.1f %s" % (n, u))
        n /= 1024.0


def base_url(handler):
    proto = handler.headers.get("X-Forwarded-Proto") or ("https" if handler.is_tls else "http")
    host = handler.headers.get("X-Forwarded-Host") or handler.headers.get("Host") or "127.0.0.1"
    return "%s://%s" % (proto, host)


def install_cmd(store, handler, token, name):
    b = base_url(handler)
    safe = re.sub(r"[^\w\-\u4e00-\u9fa5.]", "-", name)[:32] or "vps"
    return ("curl -fsSL %s/agent/install.sh | sudo bash -s -- "
            "--server %s --token %s --name '%s'" % (b, b, token, safe))


# ---------------- 上报处理 ----------------

def handle_ingest(store, sid, payload):
    ts = now_ts()
    try:
        pts = int(payload.get("ts") or 0)
        if 0 < pts <= ts and ts - pts < 7200:
            ts = pts
    except Exception:
        pass
    server = store.get_server(sid)
    if not server:
        return None
    store.save_snapshot(sid, ts, payload)

    cpu = (payload.get("cpu") or {}).get("pct") or 0
    mem = (payload.get("mem") or {}).get("pct") or 0
    disks = payload.get("disks") or []
    dmax = max([d.get("pct") or 0 for d in disks] or [0])
    net = payload.get("net") or {}
    store.add_sample(sid, ts, cpu, mem, dmax, net.get("rx_bps") or 0, net.get("tx_bps") or 0)

    th = alerts._th(store)
    recent = store.q("SELECT cpu FROM samples WHERE server_id=? ORDER BY ts DESC LIMIT 8", (sid,))
    streak = 0
    for r in recent:
        if (r["cpu"] or 0) >= th["cpu"]:
            streak += 1
        else:
            break

    h7 = store.hourly_avg_cpu(sid, 7)
    hrs = store.one("SELECT COUNT(*) n FROM hourly WHERE server_id=?", (sid,))
    ctx = {"cpu_streak": streak, "avg_cpu_7d": h7, "hours": (hrs["n"] if hrs else 0)}

    store.touch(sid, ts, payload.get("ver") or "")
    try:
        alerts.diff_snapshot(store, server, payload)
    except Exception as e:
        print("[warn] diff failed:", e)

    chk = checks.build(store.get_server(sid), payload, ctx)
    try:
        alerts.evaluate(store, server, payload, chk, ctx)
        alerts.notify(store)
    except Exception as e:
        print("[warn] alert failed:", e)

    with LOCK:
        CACHE["ov"] = (0, None)
    return {"ok": True, "score": chk["score"], "ts": ts}


# ---------------- 数据组装 ----------------

def server_card(store, s):
    ts, payload = store.get_snapshot(s["id"])
    if not payload:
        return {"id": s["id"], "name": s["name"], "online": False, "empty": True,
                "note": s["note"], "grp": s["grp"], "alerts": 0}
    h7 = store.hourly_avg_cpu(s["id"], 7)
    hrs = store.one("SELECT COUNT(*) n FROM hourly WHERE server_id=?", (s["id"],))
    chk = checks.build(s, payload, {"avg_cpu_7d": h7, "hours": (hrs["n"] if hrs else 0)})
    host = payload.get("host") or {}
    cpu = payload.get("cpu") or {}
    mem = payload.get("mem") or {}
    net = payload.get("net") or {}
    disks = payload.get("disks") or []
    root = next((d for d in disks if d.get("mount") == "/"), (disks[0] if disks else {}))
    offline = now_ts() - (s["last_seen"] or 0) > alerts._th(store)["offline"]
    openn = store.one("SELECT COUNT(*) n FROM alerts WHERE server_id=? AND resolved=0", (s["id"],))
    return {
        "id": s["id"], "name": s["name"], "note": s["note"], "grp": s["grp"],
        "online": not offline and bool(s["last_seen"]),
        "seen": s["last_seen"], "empty": False,
        "host": {"hostname": host.get("hostname"), "os": host.get("os"),
                 "kernel": host.get("kernel"), "virt": host.get("virt"),
                 "cores": host.get("cores"), "model": host.get("cpu_model"),
                 "uptime": host.get("uptime"), "ip": host.get("ip")},
        "cpu": {"pct": round(cpu.get("pct") or 0, 1), "load1": cpu.get("load1"),
                "load5": cpu.get("load5"), "load15": cpu.get("load15"),
                "procs": cpu.get("procs")},
        "mem": {"pct": round(mem.get("pct") or 0, 1), "total": mem.get("total"),
                "used": mem.get("used"), "swap_pct": (payload.get("swap") or {}).get("pct")},
        "disk": {"pct": round(root.get("pct") or 0, 1), "total": root.get("total"),
                 "used": root.get("used"), "mount": root.get("mount") or "/",
                 "count": len(disks)},
        "flags": {i["id"]: i["status"] for g in chk["groups"] for i in g["items"]},
        "spark": [round((r["cpu"] or 0), 1) for r in store.series(s["id"], 30)],
        "net": {"rx": net.get("rx_bps") or 0, "tx": net.get("tx_bps") or 0,
                "month": (chk.get("traffic") or {}).get("total") or 0,
                "quota_pct": (chk.get("traffic") or {}).get("pct")},
        "score": chk["score"], "grade": chk["grade"], "color": chk["color"],
        "headline": chk["headline"], "counts": chk["counts"],
        "keepalive": chk["keepalive"]["detected"],
        "bbr": ((payload.get("sec") or {}).get("bbr") or {}).get("cc"),
        "alerts": openn["n"] if openn else 0,
    }


def build_overview(store):
    with LOCK:
        ts, cached = CACHE["ov"]
        if cached and now_ts() - ts < 2:
            return cached
    cards = [server_card(store, s) for s in store.list_servers()]
    online = sum(1 for c in cards if c["online"])
    scoring = [c["score"] for c in cards if not c.get("empty")]
    data = {
        "servers": cards,
        "summary": {
            "total": len(cards), "online": online, "offline": len(cards) - online,
            "alerts": store.open_alert_count(),
            "avg_score": int(sum(scoring) / len(scoring)) if scoring else 0,
            "month_traffic": sum((c.get("net") or {}).get("month") or 0 for c in cards),
        },
        "alerts": store.list_alerts(only_open=True, limit=20),
        "version": VERSION,
    }
    with LOCK:
        CACHE["ov"] = (now_ts(), data)
    return data


def build_detail(store, sid):
    s = store.get_server(sid)
    if not s:
        return None
    ts, payload = store.get_snapshot(sid)
    if not payload:
        return {"id": sid, "name": s["name"], "empty": True,
                "install": {"server_id": s["id"], "note": s["note"]}}
    h7 = store.hourly_avg_cpu(sid, 7)
    hrs = store.one("SELECT COUNT(*) n FROM hourly WHERE server_id=?", (sid,))
    ctx = {"avg_cpu_7d": h7, "hours": (hrs["n"] if hrs else 0)}
    chk = checks.build(s, payload, ctx)
    ports = payload.get("ports") or []
    risks = {(r["port"], r["note"]): r for r in checks.port_risks(ports)}
    for p in ports:
        try:
            pt = int(p.get("port") or 0)
        except Exception:
            pt = 0
        p["risk"] = next((r for r in risks.values() if r["port"] == pt), None)
    return {
        "id": sid, "name": s["name"], "note": s["note"], "grp": s["grp"],
        "online": now_ts() - (s["last_seen"] or 0) <= alerts._th(store)["offline"],
        "seen": s["last_seen"], "agent_ver": s["agent_ver"], "ts": ts,
        "cloud_fw": s["cloud_fw"], "quota_gb": s["quota_gb"],
        "payload": payload, "checks": chk,
        "ports": ports,
        "series": store.series(sid, 180),
        "hourly": store.hourly_series(sid, 72),
        "events": store.events(sid, 40),
        "alerts": [a for a in store.list_alerts(limit=60) if a["server_id"] == sid],
        "host": payload.get("host") or {},
        "certs": payload.get("certs") or [],
        "services": payload.get("services") or [],
        "docker": payload.get("docker") or [],
        "cron": payload.get("cron") or [],
        "timers": payload.get("timers") or [],
    }


# ---------------- HTTP ----------------

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    # 别在响应头里暴露 Python 版本
    server_version = "vpsmon"
    sys_version = ""
    is_tls = False
    store = None

    def log_message(self, fmt, *args):
        if os.environ.get("VPSMON_DEBUG"):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    # -- 基础 --
    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
        if self.is_tls or self.headers.get("X-Forwarded-Proto") == "https":
            self.send_header("Strict-Transport-Security", "max-age=31536000")
        for k, v in (extra or []):
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False, default=str))

    def _redirect(self, to):
        self._send(302, "", "text/plain", [("Location", to)])

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except Exception:
            n = 0
        if n <= 0:
            return {}
        raw = self.rfile.read(min(n, 4 * 1024 * 1024))
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def cookies(self):
        c = SimpleCookie()
        try:
            c.load(self.headers.get("Cookie") or "")
        except Exception:
            pass
        return c

    def origin_ok(self):
        """浏览器发起的跨站 POST 直接拒掉；curl/Agent 不带 Origin，放行。"""
        o = self.headers.get("Origin")
        if not o:
            return True
        try:
            oh = urlparse(o).netloc
        except Exception:
            return False
        host = (self.headers.get("X-Forwarded-Host") or self.headers.get("Host") or "")
        return oh and oh == host

    def authed(self):
        c = self.cookies().get("vpsmon_sid")
        return bool(c and self.store.session_ok(c.value))

    # -- GET --
    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        qs = parse_qs(u.query)

        if p == "/healthz":
            return self._json({"ok": True, "ver": VERSION})

        if p == "/agent/install.sh" or p == "/agent/agent.py" or p == "/agent/vpsmon.service":
            return self.serve_file(os.path.join(os.path.dirname(HERE), "agent",
                                                os.path.basename(p)), download=True)

        if p.startswith("/assets/"):
            return self.serve_file(os.path.join(WEB, os.path.basename(p)))

        if p == "/login":
            return self.serve_file(os.path.join(WEB, "login.html"))
        if p == "/":
            if not self.authed():
                return self._redirect("/login")
            return self.serve_file(os.path.join(WEB, "index.html"))

        if not p.startswith("/api/"):
            return self._send(404, "not found", "text/plain")

        if not self.authed():
            return self._json({"error": "unauthorized"}, 401)

        if p == "/api/overview":
            return self._json(build_overview(self.store))
        if p == "/api/alerts":
            return self._json({"alerts": self.store.list_alerts(limit=200),
                               "open": self.store.open_alert_count()})
        if p == "/api/events":
            return self._json({"events": self.store.events(None, 80)})
        if p == "/api/settings":
            return self._json({
                "channels": json.loads(self.store.get("channels") or "{}"),
                "thresholds": alerts._th(self.store),
                "servers": [{"id": s["id"], "name": s["name"], "note": s["note"],
                             "grp": s["grp"], "quota_gb": s["quota_gb"],
                             "cloud_fw": s["cloud_fw"], "seen": s["last_seen"]}
                            for s in self.store.list_servers()],
                "version": VERSION,
            })
        if p.startswith("/api/server/"):
            sid = p.split("/")[3]
            d = build_detail(self.store, sid)
            if not d:
                return self._json({"error": "not found"}, 404)
            return self._json(d)
        if p == "/api/security":
            logs = self.store.q("SELECT ts,level,msg FROM events WHERE kind='auth' "
                                "ORDER BY ts DESC LIMIT 12")
            return self._json({"totp_on": self.store.get("totp_on") == "1",
                               "logins": [dict(r) for r in logs]})
        if p == "/api/export":
            data = [build_detail(self.store, s["id"]) for s in self.store.list_servers()]
            return self._json({"exported": now_ts(), "version": VERSION, "servers": data})
        return self._json({"error": "not found"}, 404)

    def serve_file(self, path, download=False):
        if not os.path.isfile(path):
            return self._send(404, "not found", "text/plain")
        ext = os.path.splitext(path)[1].lower()
        ctype = MIME.get(ext, "application/octet-stream")
        # 静态资源走 ETag 校验：升级后文件变了自动失效，没变则回 304，省流量
        st = os.stat(path)
        etag = 'W/"%x-%x"' % (int(st.st_mtime), st.st_size)
        if not download and self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            return
        with open(path, "rb") as f:
            data = f.read()
        # HTML 里的 __VER__ 换成实际版本号：静态资源带 ?v=版本 后，
        # 升级后浏览器/反代必然重新拉取，不会再出现「新 HTML + 旧 CSS」
        if ext == ".html" and b"__VER__" in data:
            data = data.replace(b"__VER__", VERSION.encode())
        extra = [("ETag", etag), ("Cache-Control", "no-cache")]
        if download:
            extra.append(("Content-Disposition",
                          "inline; filename=%s" % os.path.basename(path)))
        self._send(200, data, ctype, extra)

    # -- POST --
    def do_POST(self):
        u = urlparse(self.path)
        p = u.path

        if p == "/api/ingest":
            return self.api_ingest()
        if not self.origin_ok():
            audit(self.store, "auth", "warning", "跨站请求被拒：%s %s" % (p, self.headers.get("Origin")))
            return self._json({"error": "cross-origin request rejected"}, 403)
        if p == "/api/login":
            return self.api_login()
        if not self.authed():
            return self._json({"error": "unauthorized"}, 401)

        if p == "/api/logout":
            c = self.cookies().get("vpsmon_sid")
            if c:
                self.store.del_session(c.value)
            return self._json({"ok": True}, 200)

        if p == "/api/servers":
            return self.api_create_server()
        if p.startswith("/api/server/"):
            parts = p.split("/")
            sid = parts[3] if len(parts) > 3 else ""
            act = parts[4] if len(parts) > 4 else ""
            return self.api_server_action(sid, act)
        if p == "/api/alerts/ack":
            body = self._body()
            if body.get("all"):
                for a in self.store.list_alerts(only_open=True, limit=500):
                    self.store.ack_alert(a["id"])
            elif body.get("id"):
                self.store.ack_alert(int(body["id"]))
            return self._json({"ok": True})
        if p == "/api/settings":
            body = self._body()
            if "channels" in body:
                self.store.set("channels", json.dumps(body["channels"], ensure_ascii=False))
            if "thresholds" in body:
                th = alerts._th(self.store)
                for k, v in (body["thresholds"] or {}).items():
                    if k in alerts.DEFAULT_TH:
                        try:
                            th[k] = float(v) if k not in ("cpu_sustain",) else int(v)
                        except Exception:
                            pass
                self.store.set("thresholds", json.dumps(th))
            return self._json({"ok": True})
        if p == "/api/test-channel":
            name = (self._body() or {}).get("name") or ""
            return self._json({"ok": alerts.test_channel(self.store, name)})
        if p == "/api/totp/setup":
            secret = base64.b32encode(os.urandom(10)).decode().rstrip("=")
            self.store.set("totp_pending", secret)
            u = "otpauth://totp/%s?secret=%s&issuer=%s&digits=6&period=30" % (
                "VPS%E6%99%BA%E8%83%BD%E7%9B%91%E6%8E%A7:admin", secret, "VPS智能监控")
            return self._json({"ok": True, "secret": secret, "uri": u})
        if p == "/api/totp/enable":
            code = (self._body() or {}).get("code") or ""
            secret = self.store.get("totp_pending") or ""
            if not secret:
                return self._json({"error": "请先获取密钥"}, 400)
            if not totp_verify(secret, code):
                return self._json({"error": "验证码不正确，请核对手机时间"}, 400)
            self.store.set("totp_secret", secret)
            self.store.set("totp_on", "1")
            self.store.set("totp_pending", "")
            audit(self.store, "auth", "warning", "已开启两步验证")
            return self._json({"ok": True})
        if p == "/api/totp/disable":
            body = self._body()
            u_row = self.store.get_user("admin")
            if not u_row or not pw_check(body.get("password") or "", u_row["pw"]):
                return self._json({"error": "密码不正确"}, 400)
            self.store.set("totp_on", "0")
            self.store.set("totp_secret", "")
            audit(self.store, "auth", "warning", "已关闭两步验证")
            return self._json({"ok": True})
        if p == "/api/password":
            body = self._body()
            old, new = body.get("old") or "", body.get("new") or ""
            u_row = self.store.get_user("admin")
            if not u_row or not pw_check(old, u_row["pw"]):
                return self._json({"error": "原密码不正确"}, 400)
            # 首尾空格几乎都是手机键盘/密码管理器带进来的，存进去就再也输不对
            if new != new.strip():
                return self._json({"error": "新密码首尾不能带空格"}, 400)
            if len(new) < 8:
                return self._json({"error": "新密码至少 8 位"}, 400)
            if new == old:
                return self._json({"error": "新密码不能与原密码相同"}, 400)
            h = pw_hash(new)
            # 落盘前先自检一次，确保写进去的哈希能被验证通过
            if not pw_check(new, h):
                return self._json({"error": "内部错误：密码哈希自检失败，未做修改"}, 500)
            self.store.set_user("admin", h)
            # 旧密码保留 30 分钟宽限：改完打错字/密码管理器自动填充也不会把自己锁在外面
            self.store.set("pw_prev", u_row["pw"])
            self.store.set("pw_prev_exp", str(int(time.time()) + PW_GRACE))
            # 所有会话（含当前这个）立即失效，强制用新密码重新登录一次
            self.store.del_sessions_except("")
            audit(self.store, "auth", "warning",
                  "管理员密码已修改；全部会话已强制下线，旧密码 %d 分钟内仍可登录" % (PW_GRACE // 60))
            self._send(200, json.dumps({"ok": True, "relogin": True}),
                       "application/json; charset=utf-8", [("Set-Cookie",
                       "vpsmon_sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0")])
            return
        return self._json({"error": "not found"}, 404)

    def api_login(self):
        ip = self.client_address[0]
        body = self._body()
        name = (body.get("username") or "").strip()
        pw = body.get("password") or ""
        key = ip + "|" + name.lower()[:32]

        rec = LOGIN_FAIL.get(key)
        if rec and time.time() - rec[1] < 300 and rec[0] >= 8:
            audit(self.store, "auth", "warning", "登录已锁定：%s @ %s" % (name or "-", ip))
            return self._json({"error": "尝试次数过多，请 5 分钟后再试"}, 429)

        def fail(msg, code=401, extra=None):
            r = LOGIN_FAIL.get(key) or [0, time.time()]
            r[0] += 1
            r[1] = time.time()
            LOGIN_FAIL[key] = r
            audit(self.store, "auth", "warning",
                  "登录失败：%s @ %s（%s，第 %d 次）" % (name or "-", ip, msg, r[0]))
            left = max(0, 8 - r[0])
            d = {"error": msg if not left else "%s（还可尝试 %d 次）" % (msg, left),
                 "need_totp": bool(extra), "left": left}
            return self._json(d, code)

        u = self.store.get_user(name)
        used_old = False
        ok = bool(u) and pw_check(pw, u["pw"])
        if not ok and u and pw:
            # 改密后的宽限期：上一版密码在 PW_GRACE 内仍然认，避免改完立刻被锁在外面
            prev = self.store.get("pw_prev") or ""
            try:
                exp = int(self.store.get("pw_prev_exp") or 0)
            except Exception:
                exp = 0
            if prev and time.time() < exp and pw_check(pw, prev):
                ok = True
                used_old = True
        if not ok:
            return fail("账号或密码不正确")

        secret = self.store.get("totp_secret") or ""
        if self.store.get("totp_on") == "1" and secret:
            if not totp_verify(secret, body.get("code") or ""):
                return fail("动态验证码不正确", extra=True)

        LOGIN_FAIL.pop(key, None)
        if used_old:
            audit(self.store, "auth", "warning",
                  "使用了修改前的旧密码登录：%s @ %s（宽限期内，请尽快改用新密码）" % (name, ip))
        else:
            # 用新密码登录成功，宽限期立即关闭
            self.store.set("pw_prev", "")
            self.store.set("pw_prev_exp", "0")
        token = secrets.token_urlsafe(32)
        self.store.add_session(token, 7 * 86400)
        audit(self.store, "auth", "info", "登录成功：%s @ %s" % (name, ip))
        # 首次登录后把明文初始密码文件删掉，避免长期留在磁盘上
        try:
            pf = os.path.join(os.path.dirname(os.path.abspath(self.store.path)), "初始密码.txt")
            if os.path.exists(pf):
                os.remove(pf)
        except Exception:
            pass
        secure = "; Secure" if (self.is_tls or
                                (self.headers.get("X-Forwarded-Proto") == "https")) else ""
        self._send(200, json.dumps({"ok": True, "used_old_pw": used_old}), "application/json; charset=utf-8",
                   [("Set-Cookie",
                     "vpsmon_sid=%s; Path=/; HttpOnly; SameSite=Lax; Max-Age=%d%s"
                     % (token, 7 * 86400, secure))])

    def api_ingest(self):
        auth = self.headers.get("Authorization") or ""
        token = auth[7:].strip() if auth.lower().startswith("bearer ") else ""
        if not token:
            token = self.headers.get("X-Token") or ""
        if not token:
            return self._json({"error": "token required"}, 401)
        s = self.store.server_by_token(tok_hash(token))
        if not s:
            return self._json({"error": "invalid token"}, 403)
        if not allow_ingest(s["id"]):
            return self._json({"error": "too many requests"}, 429)
        payload = self._body()
        if not payload:
            return self._json({"error": "empty payload"}, 400)
        try:
            res = handle_ingest(self.store, s["id"], payload)
        except Exception as e:
            import traceback
            traceback.print_exc()
            return self._json({"error": "ingest failed: %s" % e}, 500)
        return self._json(res or {"error": "unknown server"}, 200)

    def api_create_server(self):
        body = self._body()
        name = (body.get("name") or "").strip()
        if not name:
            return self._json({"error": "请填写名称"}, 400)
        sid = secrets.token_hex(6)
        token = secrets.token_hex(24)
        audit(self.store, "admin", "info", "新增服务器 %s" % name)
        self.store.add_server(sid, name, tok_hash(token), body.get("note") or "",
                              body.get("grp") or "", int(body.get("quota_gb") or 0),
                              1 if body.get("cloud_fw") else 0)
        return self._json({"ok": True, "id": sid, "token": token,
                           "install": install_cmd(self.store, self, token, name)})

    def api_server_action(self, sid, act):
        s = self.store.get_server(sid)
        if not s:
            return self._json({"error": "not found"}, 404)
        body = self._body()
        if act == "delete":
            self.store.delete_server(sid)
            audit(self.store, "admin", "warning", "删除了服务器 %s" % s["name"])
            return self._json({"ok": True})
        if act == "token":
            token = secrets.token_hex(24)
            self.store.update_server(sid, token_hash=tok_hash(token))
            audit(self.store, "admin", "warning", "重发了 %s 的安装令牌，旧令牌已失效" % s["name"])
            return self._json({"ok": True, "token": token,
                               "install": install_cmd(self.store, self, token, s["name"])})
        if act == "":
            kw = {}
            for k in ("name", "note", "grp"):
                if k in body:
                    kw[k] = str(body[k])[:64]
            if "quota_gb" in body:
                kw["quota_gb"] = int(body["quota_gb"] or 0)
            if "cloud_fw" in body:
                kw["cloud_fw"] = 1 if body["cloud_fw"] else 0
            if kw:
                self.store.update_server(sid, **kw)
                with LOCK:
                    CACHE["ov"] = (0, None)
            return self._json({"ok": True})
        return self._json({"error": "not found"}, 404)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def bg_loop(store):
    last_prune = 0
    while True:
        try:
            alerts.sweep(store)
            alerts.notify(store)
            if time.time() - last_prune > 600:
                store.prune()
                last_prune = time.time()
        except Exception as e:
            print("[bg]", e)
        time.sleep(30)


def main():
    ap = argparse.ArgumentParser(description="VPS智能监控平台服务端")
    ap.add_argument("--host", default="127.0.0.1",
                    help="监听地址，默认仅本机；需要直接对外时显式写 0.0.0.0")
    ap.add_argument("--port", type=int, default=8848)
    ap.add_argument("--db", default=os.path.join(os.path.dirname(HERE), "data", "vpsmon.db"))
    ap.add_argument("--cert", default="")
    ap.add_argument("--key", default="")
    ap.add_argument("--password", default="", help="重置 admin 密码后退出")
    ap.add_argument("--totp-reset", action="store_true", help="关闭两步验证后退出（手机丢失时用）")
    args = ap.parse_args()

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    store = Store(args.db)

    if args.password:
        if len(args.password) < 8:
            print("密码太短：至少 8 位。")
            return
        store.set_user("admin", pw_hash(args.password))
        store.set("pw_prev", "")
        store.set("pw_prev_exp", "0")
        store.del_sessions_except("")
        print("admin 密码已重置，所有已登录会话已失效。")
        return

    if args.totp_reset:
        store.set("totp_on", "0")
        store.set("totp_secret", "")
        print("两步验证已关闭。")
        return

    if not store.get_user("admin"):
        pw = secrets.token_urlsafe(9)
        store.set_user("admin", pw_hash(pw))
        p = os.path.join(os.path.dirname(args.db), "初始密码.txt")
        try:
            with open(p, "w", encoding="utf-8") as f:
                f.write("用户名：admin\n密码：%s\n登录后请立即修改，登录成功后本文件会自动删除。\n" % pw)
            os.chmod(p, 0o600)
        except Exception:
            pass
        print("=" * 56)
        print(" 已创建管理员账号  admin / %s" % pw)
        print(" 密码同时写入：%s" % p)
        print("=" * 56)

    Handler.store = store
    httpd = Server((args.host, args.port), Handler)
    scheme = "http"
    if args.cert and args.key:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(args.cert, args.key)
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
        Handler.is_tls = True
        scheme = "https"

    threading.Thread(target=bg_loop, args=(store,), daemon=True).start()

    print("VPS智能监控平台 v%s 已启动" % VERSION)
    if args.host in ("0.0.0.0", ""):
        print("  [!] 正在监听所有网卡。面板请务必放在 HTTPS/隧道后面，")
        print("      或在前面用 nginx 只允许自己的 IP 访问。")
    print("  面板：%s://%s:%d" % (scheme, "127.0.0.1" if args.host in ("0.0.0.0", "") else args.host, args.port))
    print("  数据：%s" % os.path.abspath(args.db))
    print("  停止：Ctrl+C")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")


if __name__ == "__main__":
    main()
