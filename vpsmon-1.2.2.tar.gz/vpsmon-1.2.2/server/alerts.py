#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""告警引擎：快照差分、规则判定、去重与恢复、通知推送（全部标准库）。"""

import json
import time
import urllib.parse
import urllib.request

import checks

DEFAULT_TH = {
    "cpu": 90,        # 持续超阈值分钟数见 cpu_sustain
    "cpu_sustain": 3,
    "mem": 92,
    "disk": 88,
    "offline": 150,   # 秒
    "cert": 14,       # 天
    "traffic": 80,    # 配额百分比
    "score": 60,
}

LEVEL_TXT = {"critical": "[严重]", "warning": "[警告]", "info": "[提示]"}


def _th(store):
    try:
        raw = store.get("thresholds")
        th = dict(DEFAULT_TH)
        if raw:
            th.update(json.loads(raw))
        return th
    except Exception:
        return dict(DEFAULT_TH)


def _channels(store):
    try:
        return json.loads(store.get("channels") or "{}")
    except Exception:
        return {}


# ---------------- 快照差分 ----------------

def _port_key(p):
    return "%s|%s|%s|%s" % (p.get("proto") or "tcp", p.get("addr") or "",
                            p.get("port") or 0, p.get("proc") or "")


def diff_snapshot(store, server, payload):
    """端口 / 密钥 / 定时任务 三类指纹变化 -> 事件 + 告警。返回新增事件列表。"""
    sid = server["id"]
    events = []

    def load(col):
        try:
            return json.loads(server[col] or "[]")
        except Exception:
            return []

    # --- 端口 ---
    ports = payload.get("ports") or []
    prev_ports = load("prev_ports")
    if prev_ports:
        old = set(prev_ports)
        new = {_port_key(p) for p in ports}
        for k in sorted(new - old):
            bits = k.split("|")
            exposed = bits[1] in ("0.0.0.0", "::", "*")
            lvl = "warning" if exposed else "info"
            msg = "新增监听 %s/%s（%s）%s" % (bits[3] or "?", bits[2],
                                            "公网" if exposed else "本机",
                                            bits[2] if bits[2].isdigit() else "")
            events.append(store_event(store, sid, "port", lvl, "新端口：" + msg))
            if exposed:
                store.raise_alert(sid, "new_port", k, "warning", "发现新开放的端口", msg)
        for k in sorted(old - new):
            bits = k.split("|")
            events.append(store_event(store, sid, "port", "info",
                                      "端口关闭 %s/%s" % (bits[3] or "?", bits[2])))
            store.resolve_alert(sid, "new_port", k)

    # --- 授权密钥 ---
    keys = (payload.get("sec") or {}).get("keys") or {}
    cur_keys = keys.get("fingerprints") or []
    prev_keys = load("prev_keys")
    if prev_keys and cur_keys:
        added = set(cur_keys) - set(prev_keys)
        removed = set(prev_keys) - set(cur_keys)
        if added:
            msg = "authorized_keys 新增 %d 把密钥" % len(added)
            events.append(store_event(store, sid, "keys", "warning", msg))
            store.raise_alert(sid, "new_key", "authorized_keys", "critical",
                              "SSH 密钥被新增", msg + "。如果不是你自己加的，立即核查登录记录。")
        if removed:
            events.append(store_event(store, sid, "keys", "info",
                                      "authorized_keys 移除 %d 把密钥" % len(removed)))
            # 密钥被替换（既有新增也有移除）时不要自动消警，
            # 必须人工确认这次变更是自己做的。

    # --- 定时任务 ---
    cron = payload.get("cron") or []
    cur_cron = sorted([c.get("hash") or _port_key(c) for c in cron])
    prev_cron = load("prev_cron")
    if prev_cron and cur_cron:
        added = set(cur_cron) - set(prev_cron)
        if added:
            sample = [c.get("cmd", "")[:90] for c in cron
                      if (c.get("hash") or _port_key(c)) in added][:2]
            msg = "新增 %d 条定时任务：%s" % (len(added), " / ".join(sample))
            events.append(store_event(store, sid, "cron", "warning", msg))
            store.raise_alert(sid, "new_cron", "cron", "warning", "定时任务被新增", msg)

    # --- 落盘指纹 ---
    store.update_server(sid,
                        prev_ports=json.dumps(sorted({_port_key(p) for p in ports})),
                        prev_keys=json.dumps(cur_keys),
                        prev_cron=json.dumps(cur_cron))
    return events


def store_event(store, sid, kind, level, msg):
    store.add_event(sid, kind, level, msg)
    return {"kind": kind, "level": level, "msg": msg, "ts": int(time.time())}


# ---------------- 规则判定 ----------------

def evaluate(store, server, payload, chk, ctx=None):
    sid = server["id"]
    th = _th(store)
    raised = []

    def up(rule, target, level, title, detail):
        if store.raise_alert(sid, rule, target, level, title, detail):
            raised.append(rule)

    def down(rule, target=""):
        store.resolve_alert(sid, rule, target)

    # 离线告警在 sweep 里处理，这里先消掉
    down("offline")

    cpu = (payload.get("cpu") or {}).get("pct")
    if cpu is None:
        down("cpu")
    elif cpu >= th["cpu"]:
        hist = ctx.get("cpu_streak", 0) if ctx else 0
        if hist >= th.get("cpu_sustain", 3):
            up("cpu", "", "warning", "CPU 持续高负载",
               "近 %d 次采样 CPU 均在 %.0f%% 以上，当前 %.0f%%。" % (hist, th["cpu"], cpu))
    else:
        down("cpu")

    mem = (payload.get("mem") or {}).get("pct")
    if mem is None:
        down("mem")
    elif mem >= th["mem"]:
        up("mem", "", "warning", "内存接近耗尽",
           "内存使用 %.0f%%，已用 %.1f/%.1f GB。" % (
               mem, (payload["mem"].get("used") or 0) / 1073741824.0,
               (payload["mem"].get("total") or 0) / 1073741824.0))
    else:
        down("mem")

    for d in payload.get("disks") or []:
        mount = d.get("mount") or "/"
        pct = d.get("pct") or 0
        if pct >= th["disk"]:
            up("disk", mount, "critical" if pct >= 95 else "warning", "磁盘空间不足",
               "%s 已用 %.0f%%（剩余 %.1f GB）。" % (
                   mount, pct, (d.get("total", 0) - d.get("used", 0)) / 1073741824.0))
        else:
            down("disk", mount)

    keep = chk.get("keepalive") or {}
    if keep.get("idle_risk"):
        up("idle", "", "warning", "实例可能被回收",
           "近 7 天平均 CPU %.1f%%，且未检测到保活脚本。甲骨文等免费实例长期低负载有被回收的先例。" % (
               keep.get("avg_cpu_7d") or 0))
    else:
        down("idle")

    tr = chk.get("traffic") or {}
    if tr.get("pct") is not None and tr["pct"] >= th["traffic"]:
        up("traffic", "", "warning", "流量接近配额",
           "本月已用 %.1f GB，配额 %d GB，已到 %.0f%%。" % (
               tr["total"] / 1073741824.0, tr["quota_gb"], tr["pct"]))
    else:
        down("traffic")

    for c in payload.get("certs") or []:
        days = c.get("days")
        dom = c.get("domain") or "-"
        if days is None:
            continue
        if days <= th["cert"]:
            up("cert", dom, "critical" if days <= 3 else "warning", "证书即将到期",
               "%s 还有 %s 天到期（%s）。" % (dom, days, c.get("issuer") or "未知签发者"))
        else:
            down("cert", dom)

    if chk.get("score") is not None and chk["score"] < th["score"]:
        up("score", "", "warning", "安全评分偏低",
           "综合评分 %d 分（%s）。主要问题：%s" % (
               chk["score"], chk.get("grade"), chk.get("headline")))
    else:
        down("score")

    # 安全项直接升级为告警（只针对两种最要命的）
    for g in chk.get("groups") or []:
        for it in g["items"]:
            if it["id"] == "ssh_pw" and it["status"] == checks.FAIL:
                up("ssh_pw", "", "critical", "SSH 仍允许密码登录",
                   "全网扫描器会持续爆破 22 端口，建议改为仅密钥登录。")
            if it["id"] == "exposure" and it["status"] == checks.FAIL:
                up("exposure", "", "critical", "高危端口暴露公网", it["value"])

    # 安全补丁一旦落后就告警：这是最容易被自动化扫描器利用的入口
    upd = (payload.get("sec") or {}).get("updates") or {}
    secn = upd.get("security")
    if secn and secn > 0:
        up("patch", "", "warning", "有 %d 个安全补丁未安装" % secn,
           "共 %s 个包可升级。系统补丁落后等于把已公开的 CVE 留在机器上。"
           % (upd.get("pending") or "?"))
    else:
        down("patch")

    return raised


def sweep(store):
    """离线检测：由后台线程每 30 秒调用。"""
    th = _th(store)
    now = int(time.time())
    for s in store.list_servers():
        last = s["last_seen"] or 0
        if not last:
            continue
        if now - last > th["offline"]:
            if store.raise_alert(s["id"], "offline", "", "critical", "服务器离线",
                                 "已 %d 分钟没有收到上报，最后在线 %s。" % (
                                     (now - last) // 60,
                                     time.strftime("%m-%d %H:%M", time.localtime(last)))):
                store.add_event(s["id"], "offline", "critical", "服务器离线")
        else:
            if store.resolve_alert(s["id"], "offline"):
                store.add_event(s["id"], "offline", "info", "服务器恢复在线")


# ---------------- 通知推送 ----------------

def _post(url, data, headers=None, is_json=True):
    try:
        body = json.dumps(data).encode("utf-8") if is_json else urllib.parse.urlencode(data).encode()
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", "application/json" if is_json else
                       "application/x-www-form-urlencoded")
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status in (200, 201, 204)
    except Exception:
        return False


def _fmt(items):
    lines = []
    for a in items[:8]:
        lines.append("%s %s · %s\n%s" % (
            LEVEL_TXT.get(a.get("level"), ""), a.get("sname") or a.get("server_id"),
            a.get("title") or a.get("rule"), a.get("detail") or ""))
    if len(items) > 8:
        lines.append("…另有 %d 条" % (len(items) - 8))
    return "\n\n".join(lines)


def notify(store, items=None):
    """把未推送的告警发出去。返回是否成功发出。"""
    items = items or store.pending_notify()
    if not items:
        return False
    ch = _channels(store)
    text = "VPS智能监控告警\n\n" + _fmt(items)
    ok_any = False
    ids = [a["id"] for a in items]

    tg = ch.get("telegram") or {}
    if tg.get("enabled") and tg.get("token") and tg.get("chat_id"):
        ok_any |= _post("https://api.telegram.org/bot%s/sendMessage" % tg["token"],
                        {"chat_id": tg["chat_id"], "text": text,
                         "disable_web_page_preview": True})

    wc = ch.get("wecom") or {}
    if wc.get("enabled") and wc.get("webhook"):
        ok_any |= _post(wc["webhook"], {"msgtype": "text", "text": {"content": text}})

    bark = ch.get("bark") or {}
    if bark.get("enabled") and bark.get("url"):
        base = bark["url"].rstrip("/")
        ok_any |= _post(base + "/" + urllib.parse.quote("VPS智能监控告警"),
                        {"title": "VPS智能监控告警", "body": _fmt(items)}, is_json=True)

    hook = ch.get("webhook") or {}
    if hook.get("enabled") and hook.get("url"):
        ok_any |= _post(hook["url"], {"text": text, "alerts": items})

    if ok_any or not any((tg.get("enabled"), wc.get("enabled"),
                          bark.get("enabled"), hook.get("enabled"))):
        store.mark_notified(ids)
    return ok_any


def test_channel(store, name):
    ch = _channels(store)
    probe = {"id": 0, "level": "info", "sname": "测试", "title": "通知渠道测试",
             "detail": "看到这条说明配置可用。"}
    c = ch.get(name) or {}
    if not c:
        return False
    if name == "telegram" and c.get("token"):
        return _post("https://api.telegram.org/bot%s/sendMessage" % c["token"],
                     {"chat_id": c.get("chat_id"), "text": "VPS智能监控：通知渠道测试成功"})
    if name == "wecom" and c.get("webhook"):
        return _post(c["webhook"], {"msgtype": "text",
                                    "text": {"content": "VPS智能监控：通知渠道测试成功"}})
    if name == "bark" and c.get("url"):
        return _post(c["url"].rstrip("/") + "/VPS智能监控", {"title": "测试", "body": "通知渠道可用"})
    if name == "webhook" and c.get("url"):
        return _post(c["url"], {"text": "VPS智能监控：通知渠道测试", "alerts": [probe]})
    return False
