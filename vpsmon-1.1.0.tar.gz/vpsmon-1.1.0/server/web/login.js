const f = document.getElementById('f'), err = document.getElementById('err'), go = document.getElementById('go');
const codeWrap = document.getElementById('code-wrap'), codeInput = document.getElementById('code');

f.addEventListener('submit', async (e) => {
  e.preventDefault();
  go.disabled = true; go.textContent = '登录中…'; err.style.display = 'none';
  try {
    const r = await fetch('/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: f.username.value, password: f.password.value,
        code: codeInput ? codeInput.value : ''
      })
    });
    const d = await r.json().catch(() => ({}));
    if (r.ok) { location.href = '/'; return; }
    if (d.need_totp) {
      codeWrap.style.display = 'block';
      codeInput.focus();
      throw new Error('请输入两步验证动态码');
    }
    throw new Error(d.error || '登录失败');
  } catch (e2) {
    err.textContent = e2.message; err.style.display = 'block';
  }
  go.disabled = false; go.textContent = '进入面板';
});
