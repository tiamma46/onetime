#!/usr/bin/env bash
# ============================================================
#  VPS智能监控平台 · 面板端一键安装
#
#  在解压后的目录里执行：
#      sudo bash install.sh
#
#  远程一行安装（脚本和 tar 包放在同一个静态地址下）：
#      curl -fsSL https://你的地址/install.sh | sudo bash -s -- \
#          --pkg https://你的地址/vpsmon.tar.gz
#
#  可选参数：
#      --port 8848          监听端口（默认 8848）
#      --host 127.0.0.1     监听地址（默认仅本机，由 Nginx/隧道对外）
#      --dir  /opt/vpsmon   安装目录
#      --pkg  <url>         tar.gz 地址（脚本不在包里时需要）
#      --password <密码>    预设管理员密码（不填则随机生成并打印）
# ============================================================
set -euo pipefail

PORT=8848
HOST=127.0.0.1
DIR=/opt/vpsmon
PKG=""
PASSWORD=""
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd || echo "")"

while [ $# -gt 0 ]; do
  case "$1" in
    --port) PORT="${2:-8848}"; shift 2 ;;
    --host) HOST="${2:-127.0.0.1}"; shift 2 ;;
    --dir)  DIR="${2:-/opt/vpsmon}"; shift 2 ;;
    --pkg)  PKG="${2:-}"; shift 2 ;;
    --password) PASSWORD="${2:-}"; shift 2 ;;
    -h|--help) sed -n '2,22p' "$0"; exit 0 ;;
    *) echo "未知参数：$1"; exit 1 ;;
  esac
done

say() { printf "\033[1;36m==>\033[0m %s\n" "$*"; }
die() { printf "\033[1;31m错误：\033[0m %s\n" "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "需要 root，请用 sudo 执行"

# ---------- 1. Python ----------
say "检查 Python 3"
if ! command -v python3 >/dev/null 2>&1; then
  say "未找到 python3，尝试自动安装"
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq && apt-get install -y -qq python3
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y -q python3
  elif command -v yum >/dev/null 2>&1; then
    yum install -y -q python3
  else
    die "请先安装 python3（>= 3.7）"
  fi
fi
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3,7) else 1)' \
  || die "Python 版本过低，需要 3.7 及以上（当前 $(python3 -V 2>&1)）"
say "Python：$(python3 -V 2>&1)"

# ---------- 2. 取文件 ----------
TMP=""
cleanup() { [ -n "$TMP" ] && rm -rf "$TMP"; }
trap cleanup EXIT

if [ -n "$SELF_DIR" ] && [ -f "$SELF_DIR/server/run.py" ]; then
  say "使用本地目录：$SELF_DIR"
  SRC="$SELF_DIR"
else
  [ -n "$PKG" ] || die "当前不在安装包目录内，请用 --pkg 指定 tar.gz 地址"
  say "下载安装包：$PKG"
  TMP="$(mktemp -d)"
  curl -fsSL --max-time 120 "$PKG" -o "$TMP/pkg.tar.gz" || die "下载失败"
  tar -xzf "$TMP/pkg.tar.gz" -C "$TMP"
  SRC="$(find "$TMP" -maxdepth 2 -name run.py -path '*/server/*' | head -1 | xargs -r dirname | xargs -r dirname)"
  [ -f "$SRC/server/run.py" ] || die "压缩包结构不正确"
fi

# ---------- 3. 安装 ----------
say "安装到 $DIR"
mkdir -p "$DIR"
# 保留 data 目录（升级时不会丢历史数据）
if [ -d "$SRC/server" ]; then
  rm -rf "$DIR/server" "$DIR/agent" "$DIR/deploy" "$DIR/docs"
  cp -r "$SRC/server" "$SRC/agent" "$DIR/"
  [ -d "$SRC/deploy" ] && cp -r "$SRC/deploy" "$DIR/"
  [ -d "$SRC/docs" ] && cp -r "$SRC/docs" "$DIR/"
  [ -f "$SRC/README.md" ] && cp "$SRC/README.md" "$DIR/"
fi
mkdir -p "$DIR/data"
chmod 700 "$DIR/data"

if [ -n "$PASSWORD" ]; then
  say "设置管理员密码"
  ( cd "$DIR" && python3 server/run.py --db "$DIR/data/vpsmon.db" --password "$PASSWORD" )
fi

# ---------- 4. systemd ----------
say "注册 systemd 服务"
cat > /etc/systemd/system/vpsmon.service <<UNIT
[Unit]
Description=VPS 智能监控平台
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$DIR
ExecStart=/usr/bin/env python3 $DIR/server/run.py --host $HOST --port $PORT --db $DIR/data/vpsmon.db
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable vpsmon >/dev/null 2>&1 || true
systemctl restart vpsmon
sleep 3

if ! systemctl is-active --quiet vpsmon; then
  echo
  echo "服务未启动，最近日志："
  journalctl -u vpsmon -n 30 --no-pager || true
  die "启动失败"
fi

# ---------- 5. 输出 ----------
IP="$(curl -fsS --max-time 5 https://api.ipify.org 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}')"
echo
echo "============================================================"
echo " ✅ 面板已启动"
echo "    本机访问：http://127.0.0.1:$PORT"
[ "$HOST" = "0.0.0.0" ] && echo "    公网访问：http://${IP:-<服务器IP>}:$PORT   （务必尽快上 HTTPS）"
echo
if [ -f "$DIR/data/初始密码.txt" ]; then
  echo " 管理员账号（首次登录后本文件自动删除）："
  sed 's/^/     /' "$DIR/data/初始密码.txt"
else
  echo " 管理员密码已在上一步设置，或见 journalctl -u vpsmon | head -20"
  echo " 忘记密码：python3 $DIR/server/run.py --password 新密码"
fi
echo
echo " 常用命令："
echo "     systemctl status vpsmon      查看状态"
echo "     journalctl -u vpsmon -f      实时日志"
echo "     systemctl restart vpsmon     重启"
echo "============================================================"
