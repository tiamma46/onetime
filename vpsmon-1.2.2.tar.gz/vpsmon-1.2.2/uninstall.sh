#!/usr/bin/env bash
# 卸载面板（默认保留 data 目录里的历史数据）
set -euo pipefail

DIR=${1:-/opt/vpsmon}
[ "$(id -u)" -eq 0 ] || { echo "需要 root，请用 sudo 执行"; exit 1; }

systemctl disable --now vpsmon 2>/dev/null || true
rm -f /etc/systemd/system/vpsmon.service
systemctl daemon-reload

if [ -d "$DIR/data" ]; then
  echo "已停止服务。历史数据保留在：$DIR/data"
  echo "如需彻底删除：rm -rf $DIR"
else
  rm -rf "$DIR"
  echo "已卸载。"
fi
