#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SQLite 存储层：服务器、快照、采样、事件、设置。只依赖标准库。"""

import json
import os
import sqlite3
import threading
import time

DB_LOCK = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS servers (
    id           TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    token_hash   TEXT NOT NULL UNIQUE,
    note         TEXT DEFAULT '',
    grp          TEXT DEFAULT '',
    created_at   INTEGER DEFAULT 0,
    last_seen    INTEGER DEFAULT 0,
    agent_ver    TEXT DEFAULT '',
    prev_ports   TEXT DEFAULT '[]',
    prev_keys    TEXT DEFAULT '[]',
    prev_cron    TEXT DEFAULT '[]',
    cloud_fw     INTEGER DEFAULT 0,
    quota_gb     INTEGER DEFAULT 0,
    keepalive    INTEGER DEFAULT 0,
    sort         INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS latest (
    server_id TEXT PRIMARY KEY,
    ts        INTEGER,
    payload   TEXT
);
CREATE TABLE IF NOT EXISTS samples (
    server_id TEXT,
    ts        INTEGER,
    cpu       REAL,
    mem       REAL,
    disk      REAL,
    rx        REAL,
    tx        REAL
);
CREATE INDEX IF NOT EXISTS idx_samples ON samples(server_id, ts);
CREATE TABLE IF NOT EXISTS hourly (
    server_id TEXT,
    hour      INTEGER,
    cpu       REAL,
    mem       REAL,
    rx        REAL,
    tx        REAL,
    n         INTEGER,
    PRIMARY KEY (server_id, hour)
);
CREATE TABLE IF NOT EXISTS events (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id TEXT,
    ts        INTEGER,
    kind      TEXT,
    level     TEXT,
    msg       TEXT
);
CREATE INDEX IF NOT EXISTS idx_events ON events(server_id, ts);
CREATE TABLE IF NOT EXISTS alerts (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id TEXT,
    rule     TEXT,
    target   TEXT DEFAULT '',
    level    TEXT,
    title    TEXT,
    detail   TEXT,
    ts       INTEGER,
    resolved INTEGER DEFAULT 0,
    acked    INTEGER DEFAULT 0,
    notified INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_alerts ON alerts(server_id, rule, resolved);
CREATE TABLE IF NOT EXISTS settings (
    k TEXT PRIMARY KEY,
    v TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
    token   TEXT PRIMARY KEY,
    expires INTEGER
);
CREATE TABLE IF NOT EXISTS users (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    pw       TEXT,
    role     TEXT DEFAULT 'admin',
    created  INTEGER
);
"""


class Store(object):
    def __init__(self, path):
        self.path = path
        d = os.path.dirname(os.path.abspath(path))
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False, timeout=15)
        self.conn.row_factory = sqlite3.Row
        with DB_LOCK:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.executescript(SCHEMA)
            self._migrate()
            self.conn.commit()

    def _migrate(self):
        """老库升级时补齐后加的列，避免 SELECT 报 no such column。
        CREATE TABLE IF NOT EXISTS 不会改已存在的表，所以这里手工比对。"""
        want = {
            "servers": [("note", "TEXT DEFAULT ''"), ("grp", "TEXT DEFAULT ''"),
                        ("cloud_fw", "INTEGER DEFAULT 0"), ("quota_gb", "INTEGER DEFAULT 0"),
                        ("keepalive", "INTEGER DEFAULT 0"), ("sort", "INTEGER DEFAULT 0"),
                        ("prev_ports", "TEXT DEFAULT '[]'"), ("prev_keys", "TEXT DEFAULT '[]'"),
                        ("prev_cron", "TEXT DEFAULT '[]'"), ("agent_ver", "TEXT DEFAULT ''")],
            "alerts": [("target", "TEXT DEFAULT ''"), ("acked", "INTEGER DEFAULT 0"),
                       ("notified", "INTEGER DEFAULT 0")],
        }
        for table, cols in want.items():
            have = {r[1] for r in self.conn.execute("PRAGMA table_info(%s)" % table)}
            for name, decl in cols:
                if name not in have:
                    self.conn.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table, name, decl))

    # ---------- 基础 ----------
    def q(self, sql, args=()):
        with DB_LOCK:
            return self.conn.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        with DB_LOCK:
            return self.conn.execute(sql, args).fetchone()

    def x(self, sql, args=()):
        with DB_LOCK:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur

    # ---------- 设置 ----------
    def get(self, k, default=None):
        r = self.one("SELECT v FROM settings WHERE k=?", (k,))
        return r["v"] if r else default

    def set(self, k, v):
        self.x("INSERT INTO settings(k,v) VALUES(?,?) "
               "ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))

    # ---------- 服务器 ----------
    def list_servers(self):
        return self.q("SELECT * FROM servers ORDER BY sort, id")

    def get_server(self, sid):
        return self.one("SELECT * FROM servers WHERE id=?", (sid,))

    def server_by_token(self, token_hash):
        return self.one("SELECT * FROM servers WHERE token_hash=?", (token_hash,))

    def add_server(self, sid, name, token_hash, note="", grp="", quota_gb=0, cloud_fw=0):
        self.x("INSERT INTO servers(id,name,token_hash,note,grp,created_at,quota_gb,cloud_fw) "
               "VALUES(?,?,?,?,?,?,?,?)",
               (sid, name, token_hash, note, grp, int(time.time()), quota_gb, cloud_fw))

    def update_server(self, sid, **kw):
        if not kw:
            return
        keys = ", ".join("%s=?" % k for k in kw)
        self.x("UPDATE servers SET %s WHERE id=?" % keys, tuple(kw.values()) + (sid,))

    def delete_server(self, sid):
        for t in ("latest", "samples", "hourly", "events"):
            self.x("DELETE FROM %s WHERE server_id=?" % t, (sid,))
        self.x("DELETE FROM servers WHERE id=?", (sid,))

    def touch(self, sid, ts, ver=""):
        if ver:
            self.x("UPDATE servers SET last_seen=?, agent_ver=? WHERE id=?", (ts, ver, sid))
        else:
            self.x("UPDATE servers SET last_seen=? WHERE id=?", (ts, sid))

    # ---------- 快照与采样 ----------
    def save_snapshot(self, sid, ts, payload):
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        self.x("INSERT INTO latest(server_id,ts,payload) VALUES(?,?,?) "
               "ON CONFLICT(server_id) DO UPDATE SET ts=excluded.ts, payload=excluded.payload",
               (sid, ts, raw))

    def get_snapshot(self, sid):
        r = self.one("SELECT ts,payload FROM latest WHERE server_id=?", (sid,))
        if not r:
            return None, None
        try:
            return r["ts"], json.loads(r["payload"])
        except Exception:
            return r["ts"], None

    def add_sample(self, sid, ts, cpu, mem, disk, rx, tx):
        self.x("INSERT INTO samples(server_id,ts,cpu,mem,disk,rx,tx) VALUES(?,?,?,?,?,?,?)",
               (sid, ts, cpu, mem, disk, rx, tx))
        h = ts - ts % 3600
        r = self.one("SELECT n,cpu,mem,rx,tx FROM hourly WHERE server_id=? AND hour=?", (sid, h))
        if r:
            n = r["n"] + 1
            self.x("UPDATE hourly SET cpu=?,mem=?,rx=?,tx=?,n=? WHERE server_id=? AND hour=?",
                   ((r["cpu"] * r["n"] + cpu) / n, (r["mem"] * r["n"] + mem) / n,
                    max(r["rx"], rx), max(r["tx"], tx), n, sid, h))
        else:
            self.x("INSERT INTO hourly(server_id,hour,cpu,mem,rx,tx,n) VALUES(?,?,?,?,?,?,1)",
                   (sid, h, cpu, mem, rx, tx))

    def series(self, sid, limit=120):
        rows = self.q("SELECT ts,cpu,mem,disk,rx,tx FROM samples WHERE server_id=? "
                      "ORDER BY ts DESC LIMIT ?", (sid, limit))
        return [dict(r) for r in reversed(rows)]

    def hourly_series(self, sid, limit=72):
        rows = self.q("SELECT hour,cpu,mem,rx,tx,n FROM hourly WHERE server_id=? "
                      "ORDER BY hour DESC LIMIT ?", (sid, limit))
        return [dict(r) for r in reversed(rows)]

    def hourly_avg_cpu(self, sid, days=7):
        since = int(time.time()) - days * 86400
        r = self.one("SELECT AVG(cpu) a, COUNT(*) n FROM hourly WHERE server_id=? AND hour>=?",
                     (sid, since))
        if not r or not r["n"]:
            return None
        return r["a"]

    def monthly_traffic(self, sid):
        """本月（自然月）上行/下行字节累计。"""
        now = time.localtime()
        start = int(time.mktime((now.tm_year, now.tm_mon, 1, 0, 0, 0, 0, 0, -1)))
        rows = self.q("SELECT hour,rx,tx FROM hourly WHERE server_id=? AND hour>=? ORDER BY hour",
                      (sid, start))
        # hourly 存的是瞬时速率峰值；用均值近似更合理，这里取每个小时的最大值累加
        rx = sum(r["rx"] or 0 for r in rows) * 3600
        tx = sum(r["tx"] or 0 for r in rows) * 3600
        return int(rx), int(tx)

    def prune(self, sample_hours=48, hourly_days=100, event_days=30):
        now = int(time.time())
        self.x("DELETE FROM samples WHERE ts<?", (now - sample_hours * 3600,))
        self.x("DELETE FROM hourly WHERE hour<?", (now - hourly_days * 86400,))
        self.x("DELETE FROM events WHERE ts<?", (now - event_days * 86400,))
        self.x("DELETE FROM sessions WHERE expires<?", (now,))
        self.x("DELETE FROM samples WHERE server_id NOT IN (SELECT id FROM servers)")

    # ---------- 告警 ----------
    def open_alert(self, sid, rule, target=""):
        return self.one("SELECT * FROM alerts WHERE server_id=? AND rule=? AND target=? "
                        "AND resolved=0", (sid, rule, target))

    def raise_alert(self, sid, rule, target, level, title, detail):
        a = self.open_alert(sid, rule, target)
        if a:
            self.x("UPDATE alerts SET level=?,detail=?,ts=? WHERE id=?",
                   (level, detail, int(time.time()), a["id"]))
            return False
        self.x("INSERT INTO alerts(server_id,rule,target,level,title,detail,ts) "
               "VALUES(?,?,?,?,?,?,?)",
               (sid, rule, target, level, title, detail, int(time.time())))
        return True

    def resolve_alert(self, sid, rule, target=""):
        a = self.open_alert(sid, rule, target)
        if not a:
            return False
        self.x("UPDATE alerts SET resolved=? WHERE id=?", (int(time.time()), a["id"]))
        return True

    def resolve_server_alerts(self, sid, except_rules=()):
        sql = "UPDATE alerts SET resolved=? WHERE server_id=? AND resolved=0"
        args = [int(time.time()), sid]
        if except_rules:
            sql += " AND rule NOT IN (%s)" % ",".join("?" * len(except_rules))
            args += list(except_rules)
        self.x(sql, tuple(args))

    def list_alerts(self, only_open=False, limit=100):
        sql = ("SELECT a.*, s.name AS sname FROM alerts a "
               "LEFT JOIN servers s ON s.id=a.server_id WHERE 1=1")
        if only_open:
            sql += " AND a.resolved=0"
        sql += " ORDER BY a.resolved ASC, a.ts DESC LIMIT ?"
        return [dict(r) for r in self.q(sql, (limit,))]

    def ack_alert(self, aid):
        # 标记已读同时关闭该条：确认过的告警不再计入未处理，
        # 若问题还在，下一轮上报会重新产生一条新告警。
        ts = int(time.time())
        self.x("UPDATE alerts SET acked=?, resolved=? WHERE id=? AND resolved=0", (ts, ts, aid))

    def mark_notified(self, ids):
        for i in ids:
            self.x("UPDATE alerts SET notified=1 WHERE id=?", (i,))

    def pending_notify(self):
        return [dict(r) for r in self.q(
            "SELECT a.*, s.name AS sname FROM alerts a LEFT JOIN servers s ON s.id=a.server_id "
            "WHERE a.notified=0 AND a.resolved=0 ORDER BY a.ts")]

    def open_alert_count(self):
        r = self.one("SELECT COUNT(*) n FROM alerts WHERE resolved=0")
        return r["n"] if r else 0

    # ---------- 事件 ----------
    def add_event(self, sid, kind, level, msg, ts=None):
        self.x("INSERT INTO events(server_id,ts,kind,level,msg) VALUES(?,?,?,?,?)",
               (sid, ts or int(time.time()), kind, level, msg))

    def events(self, sid=None, limit=60):
        if sid:
            rows = self.q("SELECT * FROM events WHERE server_id=? ORDER BY ts DESC LIMIT ?",
                          (sid, limit))
        else:
            rows = self.q("SELECT * FROM events ORDER BY ts DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    # ---------- 会话 ----------
    def add_session(self, token, ttl):
        self.x("INSERT INTO sessions(token,expires) VALUES(?,?)", (token, int(time.time()) + ttl))

    def session_ok(self, token):
        if not token:
            return False
        r = self.one("SELECT expires FROM sessions WHERE token=?", (token,))
        return bool(r and r["expires"] > time.time())

    def del_sessions_except(self, token):
        """改密后让其他设备上的会话立即失效，只保留当前这一个。"""
        self.x("DELETE FROM sessions WHERE token<>?", (token or "",))

    def del_session(self, token):
        self.x("DELETE FROM sessions WHERE token=?", (token,))

    # ---------- 用户 ----------
    def get_user(self, username):
        return self.one("SELECT * FROM users WHERE username=?", (username,))

    def set_user(self, username, pw_hash):
        r = self.get_user(username)
        if r:
            self.x("UPDATE users SET pw=? WHERE username=?", (pw_hash, username))
        else:
            self.x("INSERT INTO users(username,pw,role,created) VALUES(?,?,'admin',?)",
                   (username, pw_hash, int(time.time())))
