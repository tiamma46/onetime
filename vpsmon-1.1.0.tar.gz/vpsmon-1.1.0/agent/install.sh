#!/usr/bin/env bash
# VPS 监控 Agent 一键安装
# 用法：curl -fsSL http://<面板地址>/agent/install.sh | sudo bash -s -- --server http://<面板地址> --token <TOKEN> --name <名称>
set -euo pipefail

SERVER=""
TOKEN=""
NAME="$(hostname 2>/dev/null || echo vps)"
INTERVAL=10

while [ $# -gt 0 ]; do
  case "$1" in
    --server) SERVER="${2:-}"; shift 2 ;;
    --token)  TOKEN="${2:-}";  shift 2 ;;
    --name)   NAME="${2:-}";   shift 2 ;;
    --interval) INTERVAL="${2:-10}"; shift 2 ;;
    *) echo "未知参数: $1"; exit 1 ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "需要 root 权限：请在命令前加 sudo"
  exit 1
fi
if [ -z "$SERVER" ] || [ -z "$TOKEN" ]; then
  echo "缺少 --server 或 --token"
  exit 1
fi

echo "==> 检查 Python 3"
if ! command -v python3 >/dev/null 2>&1; then
  echo "    未找到 python3，尝试安装"
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq && apt-get install -y -qq python3 ca-certificates curl
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 ca-certificates curl
  elif command -v yum >/dev/null 2>&1; then
    yum install -y python3 ca-certificates curl
  else
    echo "    请先手动安装 python3"; exit 1
  fi
fi

mkdir -p /opt/vpsmon /etc/vpsmon /var/lib/vpsmon

echo "==> 下载 Agent"
curl -fsSL --max-time 30 "$SERVER/agent/agent.py" -o /opt/vpsmon/agent.py
python3 -c "import py_compile;py_compile.compile('/opt/vpsmon/agent.py',doraise=True)"

echo "==> 写入配置"
cat > /etc/vpsmon/agent.json <<JSON
{"server": "$SERVER", "token": "$TOKEN", "name": "$NAME", "interval": $INTERVAL}
JSON
chmod 600 /etc/vpsmon/agent.json

echo "==> 注册 systemd 服务"
cat > /etc/systemd/system/vpsmon-agent.service <<'UNIT'
[Unit]
Description=VPS Monitor Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/env python3 /opt/vpsmon/agent.py --config /etc/vpsmon/agent.json
Restart=always
RestartSec=10
Nice=10
MemoryMax=96M

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable vpsmon-agent >/dev/null 2>&1 || true
systemctl restart vpsmon-agent
sleep 3

if systemctl is-active --quiet vpsmon-agent; then
  echo
  echo "✅ 安装完成，Agent 已运行。回到面板刷新即可看到这台机器。"
  echo "   查看状态：systemctl status vpsmon-agent"
  echo "   查看日志：journalctl -u vpsmon-agent -f"
else
  echo "⚠️  服务未启动，请查看：journalctl -u vpsmon-agent -n 50 --no-pager"
  exit 1
fi
