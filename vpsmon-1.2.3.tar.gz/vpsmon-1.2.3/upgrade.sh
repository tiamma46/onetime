#!/usr/bin/env bash
# ============================================================
#  VPS智能监控平台 · 固定路径升级
#
#  解决「每次更新都要 cd 进带版本号的目录」的问题。
#  三种用法，都不必关心解压出来的目录叫什么：
#
#    1) 在解压目录里直接执行：   sudo bash upgrade.sh
#    2) 直接给压缩包（通配符也行）：
#                                sudo bash upgrade.sh vpsmon-*.tar.gz
#    3) 直接给下载链接：
#                                sudo bash upgrade.sh https://.../vpsmon-1.2.3.tar.gz
#
#  可选参数：
#    --sha256 <值>      校验压缩包，不一致立即中止，不安装
#    --dir  <目录>      自定义安装目录（必须与首次安装时一致，默认 /opt/vpsmon）
#
#  升级只覆盖代码目录，data/（数据库、账号密码、Token）保持不变。
# ============================================================
set -euo pipefail

SRC_ARG=""
SHA=""
DIR=""

while [ $# -gt 0 ]; do
  case "$1" in
    --sha256) SHA="${2:-}"; shift 2 ;;
    --dir)    DIR="${2:-}"; shift 2 ;;
    -h|--help) sed -n '2,19p' "$0"; exit 0 ;;
    -*) echo "未知参数：$1"; exit 1 ;;
    *) SRC_ARG="$1"; shift ;;
  esac
done

[ "$(id -u)" -eq 0 ] || { echo "需要 root，请用 sudo 执行"; exit 1; }

say() { printf "\033[1;36m==>\033[0m %s\n" "$*"; }
die() { printf "\033[1;31m错误：\033[0m %s\n" "$*" >&2; exit 1; }

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMP="/tmp/vpsmon-src"

# ---------- 1. 找到源码目录 ----------
if [ -z "$SRC_ARG" ] && [ -f "$SELF_DIR/server/run.py" ] && [ -f "$SELF_DIR/install.sh" ]; then
  SRC="$SELF_DIR"
  say "使用当前目录：$SRC"
else
  [ -n "$SRC_ARG" ] || die "用法：sudo bash upgrade.sh <vpsmon-*.tar.gz | 下载链接>"
  case "$SRC_ARG" in
    http://*|https://*)
      say "下载：$SRC_ARG"
      curl -fsSL --max-time 180 "$SRC_ARG" -o /tmp/vpsmon-dl.tar.gz || die "下载失败"
      PKG="/tmp/vpsmon-dl.tar.gz"
      ;;
    *) PKG="$SRC_ARG" ;;
  esac
  [ -f "$PKG" ] || die "找不到文件：$PKG"

  if [ -n "$SHA" ]; then
    got="$(sha256sum "$PKG" | awk '{print $1}')"
    [ "$got" = "$SHA" ] || die "sha256 不一致，已中止。实际：$got"
    say "sha256 校验通过"
  fi

  # 包内可能是 vpsmon-1.2.3/ 包一层，也可能直接是 install.sh
  TOP="$(tar tzf "$PKG" 2>/dev/null | head -1)"
  STRIP=0
  case "$TOP" in
    */) STRIP=1 ;;
  esac

  say "解压到固定目录 $TMP（版本号目录名不再影响后续命令）"
  rm -rf "$TMP"
  mkdir -p "$TMP"
  tar xzf "$PKG" -C "$TMP" --strip-components="$STRIP" || die "解压失败，确认是 tar.gz"
  SRC="$TMP"
  [ -f "$SRC/install.sh" ] || die "包结构异常：解压后找不到 install.sh"
fi

# ---------- 2. 交给 install.sh ----------
if [ -n "$DIR" ]; then
  exec bash "$SRC/install.sh" --dir "$DIR"
else
  exec bash "$SRC/install.sh"
fi
